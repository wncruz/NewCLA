function resposta(rep,redireciona)
{
		if (rep == 1){
			alert('Registro gravado com sucesso.');
		}
		if (rep==2) {
 			alert('Registro atualizado com sucesso.');
		}
		if (rep==3) {
 			alert('Registro removido com sucesso.');
		}
		if (rep==4) {
 			alert('N�o foi poss�vel remover, registro est� sendo usado em outra tabela.');
		}
		if (rep==5) {
 			alert('PAR�METROS INV�LIDOS.');
		}
		if (rep==6) {
 			if (confirm('Pedido atualizado com sucesso!\n\ndeseja manter os dados na tela?') == false) {
				window.location.replace('pedido.asp');
			}
		}
		if (rep==8) {
			 alert('Registro duplicado n�o permitido.')
		}
		if (rep==10) {
 			alert('N�o foi poss�vel localizar o pr�dio.');
		}
		if (rep==11) {
 			alert('N�o foi poss�vel localizar o regime de contrata��o.');
		}
		if (rep==12) {
 			alert('N�o foi poss�vel localizar o cliente.');
 		}
		if (rep==13) {
 			alert('N�o foi poss�vel localizar a velocidade.');
		}
		if (rep==14) {
 			alert('N�o foi poss�vel localizar o servi�o.');
		}
		if (rep==15) {
 			alert('N�o foi poss�vel localizar a coordena��o executante.');
		}
		if (rep==16) {
 			alert('N�o foi poss�vel localizar a a��o.');
		}
		if (rep==17) {
 			alert('N�o foi poss�vel localizar o usu�rio.');
		}
		if (rep==18) {
 			alert('N�o foi poss�vel localizar a uf.');
		}
		if (rep==19) {
 			alert('N�o foi poss�vel localizar a cidade.');
		}
		if (rep==20) {
 			alert('N�o foi poss�vel localizar o tipo de logradouro.');
		}
		if (rep==21) {
 			alert('N�o foi poss�vel localizar o �rg�o.');
		}
		if (rep==22) {
 			alert('Dados inv�lidos ao incluir a a��o.');
		}
		if (rep==23) {
 			alert('Dados inv�lidos ao incluir a a��o do pedido.');
		}
		if (rep==24) {
 			alert('Dados inv�lidos ao incluir o agente.');
		}
		if (rep==25) {
 			alert('Dados inv�lidos ao incluir o agente do pedido.');
		}
		if (rep==26) {
 			alert('Dados inv�lidos ao incluir a coordena��o  executante.');
		}
		if (rep==27) {
 			alert('Dados inv�lidos ao incluir a distribui��o.');
		}
		if (rep==28) {
 			alert('Dados inv�lidos ao incluir o provedor.');
		}
		if (rep==29) {
 			alert('Par�metro inv�lido ao incluir o redirecionamento de solicita��o.');
		}
		if (rep==30) {
 			alert('Dados inv�lidos ao incluir o regime de contrato.');
		}
		if (rep==31) {
 			alert('Dados inv�lidos ao incluir o servi�o.');
		}
		if (rep==32) {
 			alert('Dados inv�lidos ao incluir o sistema x tipo de posi��o.');
		}
		if (rep==33) {
 			alert('Dados inv�lidos ao incluir o sistema.');
		}
		if (rep==34) {
 			alert('Dados inv�lidos ao incluir o status do pedido.');
		}
		if (rep==35) {
 			alert('Dados inv�lidos ao incluir o tipo contrato.');
		}
		if (rep==36) {
 			alert('Dados inv�lidos ao incluir o tipo de distribui��o.');
		}
		if (rep==37) {
 			alert('Dados inv�lidos ao incluir o tipo de posi��o.');
		}
		if (rep==38) {
 			alert('Dados inv�lidos ao incluir o usu�rio.');
		}
		if (rep==39) {
	    	alert('Dados inv�lidos ao incluir o velocidade.');
		}
		if (rep==40) {
    		alert('Pedido n�o encontrado.');
		}
		if (rep==41) {
    		alert('N�mero do pedido n�o encontrado.');
		}
		if (rep==42) {
	    	alert('Usu�rio n�o encontrado.');
		}
		if (rep==43) {
    		alert('Provedor ou tipo de contrato n�o encontrado.');
		}
		if (rep==44) {
    		alert('Agente n�o encontrado.');
		}
		if (rep==45) {
	    	alert('Dados inv�lidos ao alterar o cliente.');
		}
		if (rep==46) {
    		alert('Dados inv�lidos ao incluir o cliente.');
		}
		if (rep==47) {
    		alert('Dados inv�lidos ao alterar o pedido.');
		}
	 	if (rep==48) {
	    	alert('Dados inv�lidos ao incluir o pedido.');
		}
		if (rep==49) {
    		alert('Nenhum cliente foi selecionado.');
		}
		if (rep==50) {
    		alert('Par�metro inv�lido ao incluir a distribui��o x esta��o.');
		}
		if (rep==51) {
	    	alert('Par�metro inv�lido ao incluir o recurso.');
		}
		if (rep==52) {
    		alert('Par�metro inv�lido ao incluir o hist�rico.');
		}
		if (rep==53) {
    		alert('Par�metro inv�lido ao incluir a distribui��o x tipo de distribui��o.');
		}
		if (rep==54) {
	    	alert('Par�metro inv�lido ao incluir o �rg�o.');
		}
		if (rep==55) {
    		alert('Recurso n�o encontrado.');
		}
		if (rep==56) {
	    	alert('Cliente n�o encontrado.');
		}
		if (rep==57) {
	    	alert('Regime de contrato n�o encontrado.');
		}
		if (rep==58) {
	    	alert('Provedor n�o encontrado.');
		}
		if (rep==59) {
	    	alert('Par�metro inv�lido ao incluir a esta��o.');
		}
		if (rep==60) {
	    	alert('Facilidade n�o encontrada.');
		}
		if (rep==61) {
	    	alert('Esta pedido j� tem facilidades e n�o pode ser alterado.');
			window.location.replace('pedido_main.asp');
		} 
		if (rep==62) {
	    	alert('Pedido de acesso inexistente.');
		}
		if (rep==63) {
	    	alert('Facilidade n�o encontrada.');
		} 
		if (rep==64) {
	    	alert('N�o h� registros para aceita��o.');
		} 
		if (rep==65) {
	    	alert('Facilidade n�o encontrada.');
		}
		if (rep==67) {
	    	alert('N�o h� acessos aceitos neste per�odo.');
		}
		if (rep==69) {
	    	alert('Execu��o gravada com sucesso.');
		}
		if (rep==70) {
	    	alert('Data de in�cio inv�lida.');
		}
		if (rep==71) {
	    	alert('Data de t�rmino inv�lida.');
		}
		if (rep==72) {
	    	alert('A sev deve ser num�rica.');
		}
		if (rep==73) {
	    	alert('N�o h� pedido de acesso dispon�vel para aceita��o com este n�mero de acesso.');
		}
		if (rep==74) {
	    	alert('N�o h� pedidos para este cliente.');
		}
		if (rep==75) {
	    	alert('N�o h� aceita��es para este pedido.');
		}
		if (rep==76) {
	    	alert('N�o h� pedido de acesso com este n�mero de acesso.');
		}
		if (rep==77) {
	    	alert('PADE/PAC n�o encontrada.');
		}
		if (rep==78) {
	    	alert('PADE/PAC ocupada.');
		}
		if (rep==79) {
	    	alert('Facilidade j� cadastrada.');
		}
		if (rep==80) {
	    	alert('A ponta de origem j� est� sendo utilizada.');
		}
		if (rep==81) {
	    	alert('A ponta de destino j� est� sendo utilizada.');
		}
		if (rep==82) {
	    	alert('Par�metro inv�lido ao incluir data de a��o.');
		}
		if (rep==83) {
	    	alert('N� de refer�ncia j� existe.');
		}
		if (rep==84) {
	    	alert('Data do pedido inv�lida.');
		}
		if (rep==85) {
	    	alert('PADE/PAC n�o ocupada ou n�o cadastrada.');
		}
		if (rep==90) {
	    	alert('N�o pode ser criada a��o para este pedido, pois existe uma pend�ncia.');
		}
		if (rep==96) {
	    	alert('PADE/PAC "de" n�o existe.');
		}
		if (rep==97) {
	    	alert('PADE/PAC "para" n�o existe.');
		}
		if (rep==98) {
	    	alert('PADE/PAC "para" j� est� sendo utilizada.');
		}
		if (rep==99) {
	    	alert('PADE/PAC "de" n�o est� sendo utilizada com o nro de acesso informado.');
		}
		if (rep==100) {
	    	alert('A ponta de origem j� est� sendo utilizada em um pedido de rede interna.');
		}
		if (rep==101) {
	    	alert('Este pedido n�o pode ser cancelado, pois n�o est� pendente.');
		}
		if (rep==102) {
	    	alert('Recurso interno desalocado. J� � poss�vel entrar com nova solicita��o.');
		}
		if (rep==104) {
	    	alert('A mesma coordenada n�o pode ser utilizada em pares diferentes.');
		}
		if (rep==105) {
	    	alert('A quantidade m�xima � de 100 pares.');
		}
		if (rep==106) {
	    	alert('Problema na transa��o. Verifique se o registro j� existe.');
		}
		if (rep==107) {
	    	alert('Usu�rio n�o esta associado a um centro funcional.\nVerifique o cadastro de usu�rio com centro funcional.');
		}
		if (rep==108) {
 			alert('Dados inv�lidos ao incluir o centro funcional.');
		}
		if (rep==109) {
 			alert('Dados inv�lidos ao incluir associa��o do servi�o com velocidade.');
		}
		if (rep==110) {
 			alert('Registro j� existe.');
		}
	 	if (rep==111) {
	    	alert('Dados inv�lidos ao incluir endere�o de instala��o.');
		}
	 	if (rep==112) {
	    	alert('Dados inv�lidos ao incluir complemento do endere�o de instala��o.');
		}
	 	if (rep==113) {
	    	alert('Problema na transa��o.\nVerifique se o registro esta associado a algum usuario.');
		}
	 	if (rep==114) {
	    	alert('Complemento exclu�do, mas centro funcional mantido\npois esta associado a outros complementos.');
		}
		if (rep==115) {
	    	alert('Dados inv�lidos ao incluir a tipo de logradouro.');
		}
	 	if (rep==116) {
	    	alert('Dados inv�lidos ao incluir endere�o do ponto intermediario.');
		}
	 	if (rep==117) {
	    	alert('Dados inv�lidos ao incluir complemento do endere�o do ponto intermediario.');
		}
	 	if (rep==118) {
	    	alert('ID do acesso f�sico n�o existe.');
		}
	 	if (rep==119) {
	    	alert('ID do acesso f�sico n�o pertence ao propriet�rio informado.');
		}
	 	if (rep==120) {
	    	alert('Problema na transa��o.\nSe persistir comunique o suporte tecnico.');
		}
		if (rep==121) {
	    	alert('Usu�rio n�o tem o perfil solicitado.');
		}
		if (rep==122) {
	    	alert('Infra aprovada com sucesso.');
		}
		if (rep==123) {
	    	alert('Problema na transa��o de aprova��o de infra.');
		}
		if (rep==124) {
	    	alert('Processo atualizado com sucesso.');
		}
		if (rep==125) {
	    	alert('Problema na transa��o de atualiza��o de processo.');
		}
		if (rep==126) {
	    	alert('Distribuidor n�o encontrado.');
		}
		if (rep==127) {
	    	alert('Esta��o n�o encontrada.');
		}
		if (rep==128) {
	    	alert('Centro funcional n�o encontrado.');
		}
		if (rep==129) {
	    	alert('Erro durante atualiza��o de facilidade.');
		}
		if (rep==130) {
	    	alert('Problema na transa��o gerando acesso logico x fisico.');
		}
		if (rep==131) {
	    	alert('CEP n�o cadastrado, favor verificar.');
		}
		if (rep==132) {
	    	alert('Problema na transa��o do crms , contacte o suporte.');
		}
		if (rep==133) {
	    	alert('SEV em aberto. N�o dispon�vel.');
		}
		if (rep==134) {
	    	alert('SEV n�o encontrada.');
		}
		if (rep==135) {
	    	alert('CEP n�o cadastrado, favor verificar.');
		}
		if (rep==137) {
	    	alert('ID do acesso f�sico esta em fase de constru��o.');
		}
		if (rep==138) {
	    	alert('Autoriza compartilhamento do id f�sico para o endere�o ?');
		}
		if (rep==140) {
	    	alert('ID do acesso f�sico n�o pertence ao endereco de instala��o.');
		}
		if (rep==142) {
	    	alert('Aten��o existe pendencia de cria��o de cabo interno.');
		}
		if (rep==143) {
	    	alert('Alguns registros n�o foram removidos pois est�o sendo utilizado.');
		}
		if (rep==144) {
	    	alert('Solicita��o n�o pode ser conclu�da, pois existe uma pend�ncia de manobra de facilidade.');
		}
		if (rep==145) {
	    	alert('Transa��o ok. Servi�o desativado.'); 
		}
		if (rep==146) {
	    	alert('Transa��o ok. Solicita��o em processo de desativa��o.');
		}
		if (rep==147) {
	    	alert('N�o � poss�vel realizar aceita��o, sem informar execu��o.');
		}
		if (rep==148) {
	    	alert('Problema na transa��o, inserindo registro de Log.');
		}
		if (rep==149) {
	    	alert('Problema na transa��o, inserindo registro de hist�rico.');
		}
		if (rep==150) {
	    	alert('A(s) nova(s) PADE/PAC(s) do local de instala��o j� existem.');
		}
		if (rep==151) {
	    	alert('A(s) nova(s) PADE/PAC(s) do local de configura��o j� existem.');
		}
		if (rep==152) {
	    	alert('N�o � poss�vel realizar novas altera��es pois existe um processo em andamento.');
		}
		if (rep==153) {
	    	alert('Solicita��o n�o encontrada');
		}
		if (rep==159) {
	    	alert('Facilidade(s) alocada(s) com sucesso.');
		}
		if (rep==160) {
	    	alert('Erro durante o processo libera��o de facilidade');
		}
		if (rep==161) {
	    	alert('Facilidade ja esta alocada para outro pedido');
		}
		if (rep==162) {
	    	alert('PADE/PAC em processo de retirada');
		}
		if (rep==163) {
		alert('Pedido / Nro.Acesso n�o disponivel para aceita��o');
		}
		if (rep==170) {
	    	alert('Solicita��o em processo de cancelamento');
		}
		if (rep==171) {
	    	alert('Nome do cliente n�o confere com conta corrente');
		}
		if (rep==172) {
	    	alert('Execu��o ja realizada');
		}
		if (rep==173) {
	    	alert('Aceite do acesso f�sico j� Realizado');
		}
		if (rep==174) {
	    	alert('Problema durante a aloca��o de taxa do servi�o');
		}
		if (rep==175) {
	    	alert('Acesso L�gico atualizado com sucesso.');
		}
		if (rep==176) {
	    	alert('Par�metro inv�lido ao incluir configura��o do centro funcional.');
		}
		if (rep==177) {
	    	alert('Pedido j� foi alocado por um GLA/GLAE');
		}
		if (rep==178) {
	    	alert('Pedido Alocado com sucesso para usu�rio logado');
		}
		if (rep==179) {
	    	alert('SEV fora do prazo de validade.');
		}
		if (rep==180) {
	    	alert('Libera��o para servi�o realizada com sucesso.');
		}
		if (rep==181) {
	    	alert('Libera��o para servi�o n�o realizada, pois existem pendencias.');
		}
		if (rep==182) {
	    	alert('Problema na transa��o liberando para servi�o.');
		}
		if (rep==183) {
	    	alert('Problema durante o aceite, Nro. do Acesso Pta EBT inv�lido.');
		}
		if (rep==184) {
	    	alert('Nro. do Acesso Pta EBT inv�lido.');
		}
		if (rep==185) {
	    	alert('Nro. da SEV fora de Padr�o');
		}
		if (rep==574) {
	    	alert('Este registro est� sendo utilizado e n�o pode ser exclu�do.');
		}
		if (rep==576) {
		alert('N�o � possivel alterar a plataforma para este recurso.');
		}
		if (rep==674) {
	    	alert('Falta m�dulo auxiliar de processo - 647.');
		}
		if (rep==675) {
	    	alert('Transa��o ok. Servi�o cancelado.'); 
		}
		if (rep==192) {
	    	alert('A SEV mestra s� pode ser utilizada com acessos pr�prios.'); 
		}
		if (rep==588) {
	    	alert('Usu�rio n�o possui acesso a esta esta��o.'); 
		}
		if (rep==593) {
	    	alert('Libera��o para servi�o n�o realizada, pois � necess�rio alocar facilidades para o acesso.');
		}		
		if (rep==600) {
	    	alert('Existe um processo de altera��o n�o conclu�do para este acesso f�sico.');
		}	
		if (rep==602) {
	    	alert('SEV n�o finalizada , aguardando resposta da solu��o final.');
		}		
		if (rep==603) {
	    	alert('SEV em processo de Projeto Solu��o.');
		}	
		if (rep==604) {
	    	alert('SEV em processo de Rean�lise de Viabilidade.');
		}	
		if (rep==605) {
	    	alert('Favor enviar a SEV para o processo de Rean�lise de Viabilidade.');
		}	
		if (rep==606) {
	    	alert('Acesso diferente da solu��o proposta no estudo de viabilidade');
			
			//RAIO X - Devido a um Bug, a mensagem abaixo foi inserida na pr�pria p�gina: checkSevMestra.asp
			//alert('Esta n�o � a solu��o indicada como resposta da SEV pelo processo de viabilidade.\nClique OK para prosseguir com a escolha deste acesso � seu login ser� registrado para auditoria futura de uso em n�o conformidade com a viabilidade.');

		}	
		if (rep==607) {
	    	alert('Acesso com Impossibilidade de atendimento');
		}	
		if (rep==608) {
	    	alert('Esta��o de acesso diferente da solu��o proposta no estudo de viabilidade');
		}	
		if (rep==609) {
	    	alert('SEV em processo de Rean�lise Contesta��o.');
		}
		
		if (rep==731) {
	    	alert('Acesso Invi�vel Financeiro ');
		}	
		
		
		
		
		if (rep==701) {
	    	alert('N�MERO DA SEV FORA DO PADR�O.');
		}		
		if (rep==702) {
	    	alert('N�MERO DA SEV N�O ENCONTRADA.');
		}	
		if (rep==703) {
	    	alert('N�MERO DA SEV EM ABERTO. N�O DISPON�VEL.');
		}		
		if (rep==704) {
	    	alert('N�MERO DA SEV FORA DO PRAZO DE VALIDADE.');
		}	
		if (rep==705) {
	    	alert('N�MERO DA SEV EM PROCESSO DE REAN�LISE DE VIABILIDADE.');
		}	
		if (rep==706) {
	    	alert('N�MERO DA SEV COM IMPOSSIBILIDADE DE ATENDIMENTO.');
		}	
		if (rep==707) {
	    	alert('N�MERO DA SEV CANCELADA.');
		}	
		if (rep==708) {
	    	alert('N�MERO DA SEV COM ENDERE�O N�O PADRONIZADO.');
		}	
		if (rep==709) {
	    	alert('N�MERO DA SEV EM PROCESSO DE REAN�LISE CONTESTA��O.');
		}	
		
		if (rep==710) {
	    	alert('N�O � POSS�VEL MANTER O MESMO ACESSO F�SICO, POIS A ORDEM ENTRY EST� COM A INDICA��O DE MUDAN�A DE ENDERE�O.');
		}	
		
		if (rep==720) {
	    	alert('N�MERO DA SEV SEM STATUS.');
		}	
		
        if (rep==721) {
	    	alert('A VIABILIDADE N�O ACEITA ACESSO MISTO!');
		}
		
		
		if (rep==711) {
			
			//RAIO X - Devido a um Bug, a mensagem abaixo foi inserida na pr�pria p�gina: checkSevMestra.asp
			//alert('Esta n�o � a solu��o indicada como resposta da SEV pelo processo de viabilidade.\nClique OK para prosseguir com a escolha deste acesso � seu login ser� registrado para auditoria futura de uso em n�o conformidade com a viabilidade.');
			//alert('Esta n�o � a solu��o indicada como resposta da SEV pelo processo de viabilidade');
						if (confirm('--Esta n�o � a solu��o indicada como resposta da SEV pelo processo de viabilidade.\nClique OK para prosseguir com a escolha deste acesso � seu login ser� registrado para auditoria futura de uso em n�o conformidade com a viabilidade.')){
							parent.AdicionarAcessoListaAprov()
						}

		}	
		
		if (rep==725) {
	    	alert('O ORDER ENTRY CFD N�O ACEITA ACESSO MISTO!');
		}

		if (rep==726) {
	    	alert('O STATUS FOI ENVIADO COM SUCESSO AO SNOA.');
		}
		if (rep==727) {
	    	alert('A SOLICITA��O DA ORDEM FOI ENVIADO COM SUCESSO AO SNOA.');
		}
		
		if (rep==728) {
	    	alert('O PEDIDO J� FOI SOLICITADO AO SNOA.');
		}
		
		if (rep==729) {
	    	alert('O PEDIDO J� FOI GERADO PELO SNOA. ');
		}
		
		if (rep==730) {
	    	alert('A TECNOLOGIA EST� INATIVA');
		}
		
		if (rep==731) {
	    	alert('N�MERO DA SEV COM STATUS INVI�VEL FINANCEIRO. ');
		}
		if (rep==740) {
	    	alert('FAVOR ALOCAR A PORTA DO UPLINK DO SWITCH INTERCONEXAO. ');
		}
		if (rep==750) {
	    	alert('FAVOR ALOCAR A PORTA DO UPLINK DO SWITCH EDD. ');
		}
		if (rep==760) {
	    	alert('FAVOR ALOCAR A PORTA PE. ');
		}
		if (rep==770) {
	    	alert('FAVOR ALOCAR A PORTA DO UPLINK DO SWITCH METRO. ');
		}
		
		if (rep==780) {
	    	alert('FAVOR EFETUAR A GRAVA��O DOS DADOS T�CNICOS. ');
		}
		if (rep==800) {
	    	alert('Esta tecnologia x facilidade est� restrita a compartilhamento de um �nico cliente. Deseja Continuar? ');
		}

		

		
}