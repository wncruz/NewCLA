function AdicionarAcessoListaAlteracao(){

	with (document.forms[1]) //Form2
	{
		if (hdnIntIndice.value == "")
		{
			alert("Favor editar um acesso para alter�-lo")
			return
		}
		var blnAchou = false
		for (var intIndex=0;intIndex<rdoPropAcessoFisico.length;intIndex++)
		{
			if (rdoPropAcessoFisico[intIndex].checked)
			{
				blnAchou = true
			}
		}
		if (!blnAchou)
		{
			alert("Propriet�rio do Acesso F�sico � um Campo Obrigat�rio.")	
			rdoPropAcessoFisico[0].focus()
			return
		}
		

		if (cboTecnologia[cboTecnologia.selectedIndex].innerText == "RADIO")
		{
			try{
				if (cboTipoRadio.value != ""){
					if (!ValidarCampos(cboVersaoRadio,"Versao do Radio")) return false
				}
				else
				{
					if (cboVersaoRadio.value != ""){
						alert('A Vers�o do R�dio n�o deve ser preenchida sem o preenchimento do Tipo de R�dio.')
						return false
					}
				}

			}
			catch(e){}
		}
		if ((rdoPropAcessoFisico[1].checked) && (cboTecnologia.value == ""))
		{
			alert("Tecnologia � um Campo Obrigat�rio.")	
			cboTecnologia.focus();
			return
		}

		var objNodeAux = objXmlGeral.selectNodes("//Acesso[cboTipoPonto='I']")
		if (objNodeAux.length == 1 && cboTipoPonto.value == 'I'){
			if (objNodeAux[0].childNodes[0].text != hdnIntIndice.value){
				alert("N�o � poss�vel adicionar mais que um Ponto de Instala��o.")
				return
			}	
		}

		if (!ValidarCampos(cboVelAcesso,"Velocidade do Acesso F�sico")) return

		var strVel = cboVelAcesso[cboVelAcesso.selectedIndex].text
		if (strVel == "2M" || strVel == "34M" || strVel == "155M" || strVel == "622M"){
			if (!ValidarCampos(cboTipoVel,"Para as Velocidades de 2M/34M/155M/622M o Tipo de Velocidade")) return
		}
		if (!ValidarCampos(txtQtdeCircuitos,"Quantidade de Circuitos")) return
		if (txtQtdeCircuitos.value == 0){alert("Quantidade de Circuitos dever ser maior ou igual a um.");return}
		if (!ValidarCampos(cboProvedor,"Provedor")) return
		//Endere�o do Acesso F�sico
		if (!ValidarCampos(cboUFEnd,"Estado")) return
		if (!ValidarCampos(txtEndCid,"Cidade")) return
		if (!ValidarCampos(cboLogrEnd,"Logradouro")) return
		if (!ValidarCampos(txtEnd,"Nome do Logradouro")) return
		if (!ValidarCampos(txtNroEnd,"N�mero")) return
		if (!ValidarCampos(txtBairroEnd,"Bairro")) return
		if (!ValidarCampos(txtCepEnd,"CEP")) return
		if (!ValidarTipoInfo(txtCepEnd,2,"CEP")) return false;
		if (!ValidarCampos(txtContatoEnd,"Contato")) return
		if (!ValidarCampos(txtTelEndArea,"Telefone")) return false
		if (txtTelEndArea.value.length != 2)
		{ 
			alert("C�digo de area do telefone inv�lido.")
			txtTelEndArea.focus()
			return false
		}	
		if (!ValidarCampos(txtTelEnd,"Telefone")) return
		if (!ValidarCampos(txtCNPJ,"CNPJ do Endere�o de Instala��o")) return
		if (!VerificarCpfCnpj(txtCNPJ,2)) return false
		
		if (!ValidarCampos(cboTipoPonto,"Tipo do Ponto(Instala��o/Intermedi�rio)")) return false
		if (rdoPropAcessoFisico[1].checked && parseInt("0"+cboTecnologia.value) != 4)
		{
			if (!ValidarCampos(cboInterFaceEnd,"Interface")) return
		}	

		var intRet=alertbox('Deseja permanecer com os dados?','Sim','N�o','Sair')
		switch (parseInt(intRet))
		{
			case 1:
				xmlUpd(false)
				updOrdemXml()
				AtualizarLista()
				break		
			case 2:
				xmlUpd(true)
				updOrdemXml()
				AtualizarLista()
				break
		}
		cboVelAcesso.focus()
	}
}	

function AprovarAlteracao(Sol_ID)
{

		if (!GravarAlteracao()) return
		
		self.setTimeout

		var intRet=alertbox('Confirma Aprova��o da Avalia��o ?','Sim','N�o')
		switch (parseInt(intRet))
		{
			case 1:
				//GravarAlteracao()
				
				with (document.Form4)
				{
					
					hdnAcao.value = "AprovarAcesso"
					target = "IFrmProcesso"
					action = "ProcessoSolic.asp"
					submit()
					
					//alert('pos submit')
					//target = "GERENCIAMENTO_MAIN.ASP"
					//action = "GERENCIAMENTO_MAIN.ASP"
					//submit()
				}
				break

			case 2:
				
				return
				break
		}

}


function DevolverParaGIC(Sol_ID)
{		
		
		
		if (!GravarAlteracao()) return
		
		
		var intRet=alertbox('Confirma Devolu��o para o GIC ?','Sim','N�o')
		switch (parseInt(intRet))
		{
			case 1:
				
				with (document.Form4)
				{
					hdnAcao.value = "DevolverAcesso"
					target = "IFrmProcesso"
					action = "ProcessoSolic.asp"
					submit()
					//alert('teste')
				}
				break

			case 2:
				
				return
				break
		}

}

function GravarAlteracao()
{
	with (document.forms[0])
	{
		
		
		if (!ValidarCampos(txtRazaoSocial,"Nome do Cliente/Raz�o Social")) return
		if (!ValidarCampos(txtNomeFantasia,"Nome Fantasia")) return false
		if (!ValidarCampos(txtContaSev,"Conta Corrente")) return false
		if (!ValidarCampos(txtSubContaSev,"Sub Conta")) return false
		
//LPEREZ - 24/10/2005				
/*
		if (cboGrupo.value != "")
		{
			if(!ValidarCampos(cboOrigemSol,"Origem Solicita��o")) return	
		}else{
			cboOrigemSol.value = null;
		}
*/		
//LP
		

		if (!IsEmpty(cboSistemaOrderEntry.value))
		{
			if (IsEmpty(txtOrderEntry[0].value) || IsEmpty(txtOrderEntry[1].value) || IsEmpty(txtOrderEntry[2].value))
			{ 
				alert("Order Entry incompleta.Favor preencher Sistema/Ano/Nro/Item.")
				cboSistemaOrderEntry.focus()
				return false
			}
			else
			{	
				if (parseInt(txtOrderEntry[0].value) < 1964)
				{
					alert("Ano da Order Entry inv�lido. Ano dever ser maior ou igual a 1964.")
					return false
				}
				else
				{
					hdnOrderEntry.value = cboSistemaOrderEntry.value + txtOrderEntry[0].value + txtOrderEntry[1].value + txtOrderEntry[2].value
				}	
			}	
		}	
		if (!MontarDesigServico()) return false
		
		if (!ValidarCampos(cboServicoPedido,"Servi�o")) return false
		if (!ValidarCampos(cboVelServico,"Velocidade do Servi�o")) return false

		if (!ValidarCampos(txtNroContrServico,"N� do Contrato Servi�o")) return false

		//Designa��o do Acesso Principal
		hdnDesigAcessoPri.value = ""
		if (txtDesigAcessoPri.value != "" && txtDesigAcessoPri.value.length < 7)
		{
			alert("Designa��o do Acesso Principal(678) fora de padr�o 678N7.")
			txtDesigAcessoPri.focus()
			return false
		}
		
		if (txtDesigAcessoPri.value != "" && txtDesigAcessoPri.value.length == 7)
		{
			hdnDesigAcessoPri.value = txtDesigAcessoPri0.value + txtDesigAcessoPri.value
		}

		if (!ValidarTipoInfo(txtDtIniTemp,1,"Data In�cio Tempor�rio")) return false;
		if (!ValidarTipoInfo(txtDtFimTemp,1,"Data Fim Tempor�rio")) return false;
		if (!ValidarTipoInfo(txtDtDevolucao,1,"Data Devolu��o Tempor�rio")) return false;
		//if (!ValidarCampos(txtDtEntrAcesServ,"Data Desejada de Entrega do Acesso ao Servi�o")) return false;
		if (!ValidarTipoInfo(txtDtEntrAcesServ,1,"Data Desejada de Entrega do Acesso ao Servi�o")) return false;
		if (!ValidarTipoInfo(txtDtPrevEntrAcesProv,1,"Data Prevista de Entrega do Acesso pelo Provedor")) return false;

	}
	
	
	//Verifica se tem acesso adicionado
	var objNode = objXmlGeral.selectNodes("//xDados/Acesso")
	if (objNode.length == 0){
		alert("Informa��es do Acesso s�o Obrigat�rias.")
		document.forms[1].rdoPropAcessoFisico[0].focus()
		return false
	}

	var objNodeAux = objXmlGeral.selectNodes("//Acesso[cboTipoPonto='I']")
	if (objNodeAux.length == 0){
		alert("� necess�rio pelo menos um ponto de instala��o.")
		return false
	}

	with (document.forms[1]){
		
		//GLA � um campo obrigar�rio para TER/CLLI
		//var blnAchou = VerificaPropAcesso('TER')
		//if (blnAchou && IsEmpty(hdntxtGLA.value) && hdnObrigaGla.value == "1" ){
		//	alert("GLA � um campo obrigat�rio.")
		//	return false
		//}	
		blnAchou = VerificaPropAcesso('CLI')
		if (blnAchou && IsEmpty(hdntxtGLA.value) && hdnObrigaGla.value == "1" ){
			alert("GLA � um campo obrigat�rio.")
		//	return false
		}	
	}	

	


	with (document.forms[2]) //Form3
	{


		var blnAchouSatelite = false


		if (IsEmpty(document.Form2.hdnUserGICL.value)){alert('GIC-L � um campo obrigat�rio.');return false}
		
		if (!ValidarCampos(cboLocalEntrega,"Esta��o do Local de Entrega")) return false
		if (!ValidarCampos(cboLocalConfig,"Esta��o do Local de Configura��o")) return false

		
		var objNode = objXmlGeral.selectNodes("//xDados/Acesso")
		if (objNode.length == 1){
			for (var intIndex=0;intIndex<objNode.length;intIndex++){
				var intChave = objNode[intIndex].childNodes[0].text
				var intTec = RequestNodeAcesso(objXmlGeral,"cboTecnologia",intChave)
				if (intTec == 4) blnAchouSatelite = true
			}
		}	
		
		
		if (!ValidarCampos(cboOrgao,"Org�o")) return
		if (IsEmpty(hdntxtGICN.value)){alert('GIC-N � um campo obrigat�rio.');txtGICN.focus();return false}

	}


	document.Form4.hdnXml.value = ""
	for (var intIndex=0;intIndex<document.Form1.elements.length;intIndex++){
		var elemento = document.Form1.elements[intIndex];
		if (elemento.type != 'button'){
			AdicionarNode(objXmlGeral,elemento.name,elemento.value)
		}	
	}
	


	//Outros campos
	AdicionarNode(objXmlGeral,"hdnServico",document.Form1.cboServicoPedido.value)
	if (document.Form2.hdnUserGICL.value != "")	AdicionarNode(objXmlGeral,"hdntxtGICL",document.Form1.hdnUserGICL.value)
	if (document.Form2.hdntxtGLA.value != "")	AdicionarNode(objXmlGeral,"hdntxtGLA",document.Form2.hdntxtGLA.value)
	if (document.Form2.hdntxtGLAE.value != "")	AdicionarNode(objXmlGeral,"hdntxtGLAE",document.Form2.hdntxtGLAE.value)


	with (document.forms[0]) //Form3
	{
		//Tipo do Contrato
		if (document.forms[0].rdoNroContrato[0].checked) AdicionarNode(objXmlGeral,"intTipoContrato",1)
		if (document.forms[0].rdoNroContrato[1].checked) AdicionarNode(objXmlGeral,"intTipoContrato",2)
		if (document.forms[0].rdoNroContrato[2].checked) AdicionarNode(objXmlGeral,"intTipoContrato",3)
	}



	for (var intIndex=0;intIndex<document.Form3.elements.length;intIndex++){
		var elemento = document.Form3.elements[intIndex];
		if (elemento.type != 'button'){
			AdicionarNode(objXmlGeral,elemento.name,elemento.value)
		}	
	}



	//Verifica se o usu�rio editou e n�o atualizou a lista
	if (AcessoAlteradoNaoAtualizado()){
		var intRet=alertbox('As informa��es do acesso atualmente editado foram alteradas. Deseja atualiz�-la e prosseguir com a grava��o da solicita��o?','Sim','N�o','Sair')
		switch (parseInt(intRet))
		{
			case 1:
				if (!AdicionarAcessoLista(true)) return false
				break
			case 3:
				return 
				break
		}		
	}


/* alterado por PSOUTO
	ACERTO NA RN DE AVALIADOR


	with (document.Form4){
		hdnAcao.value = "AlterarInfoAcesso"
		hdnXml.value = objXmlGeral.xml
		target = "IFrmProcesso"
		action = "ProcessoSolic.asp"
		//alert('antes submit')
		submit()
		return true
	}	
	
*/	
	//alert(objXmlGeral.xml)
	//return false
	with (document.Form4){
		
		hdnAcao.value = "AlterarInfoAcesso"
		var valores = 'gravaavaliacao.asp?hdnAcao=' + hdnAcao.value + '&hdnTipoAcao=' + hdnTipoAcao.value
		valores = valores + '&hdnIdAcessoLogico=' + hdnIdAcessoLogico.value + '&hdnSolId=' + hdnSolId.value + '&hdn678=' + hdn678.value + '&hdnTipoProcesso='+ hdnTipoProcesso.value
		Retornas = window.showModalDialog(valores, objXmlGeral, 'dialogHeight: 300px; dialogWidth: 600px; dialogTop: px; dialogLeft: px; edge: Raised; center: Yes; help: No; resizable: No; status: No;')
		return Retornas
		
		}
	
}

