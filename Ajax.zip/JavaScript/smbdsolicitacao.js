function SelVelAcesso(obj)
{
	with (document.forms[1])
	{
		if (cboVelAcesso.value == "")
		{
			cboVelAcesso.value = obj.value
		}
	}
}

function ResgatarDesigServicoGravado(obj)
{
	with (document.forms[0])
	{
		hdnAcao.value = "ResgatarPadraoServico"
		if (obj == '[object]')
		{
			hdnCboServico.value = obj.value
		}
		else
		{
			hdnCboServico.value = obj + ",0"
		}	
		target = "IFrmProcesso"
		action = "ProcessoCla.asp"
		submit()
	}	
}

function VerificaPropAcesso(strProp){
	var objNode = objXmlGeral.selectNodes("//xDados/Acesso")
	//Refaz a lista de Ids no IFRAME
	for (var intIndex=0;intIndex<objNode.length;intIndex++){
		strPropAcesso = RequestNodeAcesso(objXmlGeral,"rdoPropAcessoFisico",objNode[intIndex].childNodes[0].text)
		if (strPropAcesso == strProp){
			return true
		}
	}
	return false
}

function ResgatarGLA()
{
	var strPropAcesso = new String("")
	var blnAchouTER
	var blnAchouCLI

	blnAchouTER = false
	blnAchouCLI = false
	
	if (document.forms[1].hdnObrigaGla.value == "0") return false
	
	if (!IsEmpty(document.forms[0].txtRazaoSocial.value))
	{
		document.forms[1].hdnRazaoSocial.value = document.forms[0].txtRazaoSocial.value
		blnAchouTER = VerificaPropAcesso('TER')
		blnAchouCLI = VerificaPropAcesso('CLI')
		if (blnAchouTER || blnAchouCLI){
			if (arguments.length > 0) {
				document.forms[1].hdnAcao.value = "ResgatarGLA&Gravar"
			}else{
				document.forms[1].hdnAcao.value = "ResgatarGLA"
			}	
			document.forms[1].target = "IFrmProcesso3"
			document.forms[1].action = "SMBDProcessoSolic.asp"
			document.forms[1].submit()
			return true
		}	
	}
	else
	{
		return false
	}
}

function EsconderTecnologia(intProcede)
{
	with (document.forms[1])
	{
		try{
			ReenviarSolicitacao(138,2)//limpa o acesso f�sico compartilhado
			divIDFis1.style.display = 'none'
			spnBtnLimparIdFis1.innerHTML =''
		}catch(e){}

		if (rdoPropAcessoFisico[1].checked)
		{
			divTecnologia.style.display = ""
		}
		else
		{
			if (divTecnologia.style.display == "")
			{
				cboTecnologia.value = ""
				divTecnologia.style.display = "none"
			}	
		}
		
		//Seleciona provedor embratel
		if (rdoPropAcessoFisico[1].checked)
		{
			SelProvedorEBT()
		}
		else
		{
			if (parseInt("0"+intProcede) != 1)
			{
				cboProvedor.disabled = false;
				cboProvedor.value = ""
				spnRegimeCntr.innerHTML = "<select name=cboRegimeCntr style=width:170px><Option></Option></select>"
				spnPromocao.innerHTML = "<select name=cboPromocao style=width:170px><Option></Option></select>"
			}
		}
	}
}

function ResgatarCidade(obj,intCid,objCNL)
{
	with (document.forms[1])
	{
		if (objCNL.value == "" ) return
		if (obj.value == "")
		{
			alert("Selecione a UF.")
			objCNL.value = ""
			if (intCid == 1) cboUFEnd.focus()
			else cboUFEndDest.focus()
			return
		}
		hdnAcao.value = "ResgatarCidadeCNL"
		hdnCNLNome.value = objCNL.name
		hdnUFAtual.value = obj.value

		if (intCid == 1){
			if (hdnCNLAtual.value == objCNL.value) return
			hdnCNLAtual.value = objCNL.value
			hdnNomeCboCid.value = "EndCid"
			hdnNomeTxtCidDesc.value = "txtEndCidDesc"
		}else{
			if (hdnCNLAtual1.value == objCNL.value) return
			hdnCNLAtual1.value = objCNL.value
			hdnNomeCboCid.value = "EndCidDest"
			hdnNomeTxtCidDesc.value = "txtEndCidDescDest"
		}
		
		target = "IFrmProcesso"
		action = "SMBDProcessoSolic.asp"
		submit()
	}
}

function ResgatarSev()
{
	with (document.forms[0])
	{
		if (txtNroSev.value != "")
		{
			hdnAcao.value = "ResgatarSev"
			target = "IFrmProcesso"
			action = "SMBDProcessoSolic.asp"
			submit()
		}
		else
		{
			alert("Informe o n�mero da sev.")
			txtNroSev.focus()
			return
		}
	}
}

function VerificarCidadeSev()
{
	with (document.forms[1])
	{
		if (txtEndCidDesc.value == "")
		{
			alert("Cidade da SEV n�o encontrada  para usu�rio atual.")
			return
		}
	}

}

function NovoCliente()
{
	document.forms[0].txtRazaoSocial.value = ""
	document.forms[0].txtSubContaSev.value = ""
	document.forms[0].txtNomeFantasia.value = ""
	document.forms[0].txtContaSev.value = ""
	document.forms[1].cboLogrEnd.value = ""
	document.forms[1].txtEnd.value = ""
	document.forms[1].txtNroEnd.value = ""
	document.forms[1].cboUFEnd.value = ""
	document.forms[1].txtEndCid.value = ""
	document.forms[1].txtCepEnd.value = ""
	document.forms[1].txtComplEnd.value = ""
	document.forms[1].txtBairroEnd.value = ""
	document.forms[1].txtContatoEnd.value = ""
	document.forms[1].txtTelEnd.value = ""
	document.forms[1].txtEndCidDesc.value = ""
	document.forms[1].txtCNPJ.value = ""
	document.forms[1].txtIE.value = ""
	document.forms[1].txtIM.value = ""
}

function SelecionarLocalConfig(obj)
{
	with (document.forms[2])
	{
		if (cboLocalConfig.value == "")
		{
			cboLocalConfig.value = obj.value 
		}
	}
}

function ResgatarUserCoordenacao(obj)
{
	
	if (obj.value != eval("document.forms[2].hdn"+obj.name+".value"))
	{
		with (document.forms[2])
		{
			eval("document.forms[2].hdn"+obj.name+".value = '"+obj.value+"'")
			hdnCoordenacaoAtual.value = obj.name
			hdnAcao.value = "ResgatarUserCoordenacao"
			target = "IFrmProcesso"
			action = "SMBDProcessoSolic.asp"
			submit()
		}	
	}
}

function SistemaOrderEntry()
{
	with (document.forms[0])
	{
		if (cboSistemaOrderEntry.value == "")
		{
			if (!txtOrderEntry[0].readOnly)			
			{
				txtOrderEntry[0].readOnly = true
				txtOrderEntry[1].readOnly = true
				txtOrderEntry[2].readOnly = true
				txtOrderEntry[0].value = ""
				txtOrderEntry[1].value = ""
				txtOrderEntry[2].value = ""
			}	

		}	
		else
		{
			txtOrderEntry[0].readOnly = false
			txtOrderEntry[1].readOnly = false
			txtOrderEntry[2].readOnly = false
		}
	} 
}

function ProcurarCEP(intTipo,intObj)
{
	with (document.forms[1])
	{
		hdnAcao.value = "ProcurarCEP"
		hdnTipoCEP.value = intTipo
		if (intTipo == 1){ hdnCEP.value = txtCepEnd.value}
		else {hdnCEP.value = txtCepEndDest.value}
		if (hdnCEP.value.length < 5 && intObj == 1)
		{
			alert("CEP deve ser maior que cinco caracteres.")
			return
		}
		switch (intTipo)
		{
			case 1:
				txtNroEnd.value = ""
				txtComplEnd.value = ""	
				break
			case 2:
				txtNroEndDest.value = ""
				txtComplEndDest.value = ""	
				break
		}	
		target = "IFrmProcesso"
		action = "SMBDProcessoSolic.asp"
		submit()
	}	
}

function ResgatarEstacaoDestino(objCNL,objCompl)
{
	with (document.forms[1])
	{
		if (objCNL.value != "" && objCompl.value != "")
		{
			if (objCNL.value + objCompl.value != hdnEstacaoDestino.value)
			{
				hdnEstacaoDestino.value = objCNL.value + objCompl.value
				hdnAcao.value = "ResgatarEstacaoDestino"
				target = "IFrmProcesso2"
				action = "SMBDProcessoSolic.asp"
				submit()
			}	
		}
	}
}

function ResgatarEstacaoOrigem(objCNL,objCompl)
{
	with (document.forms[1])
	{
		if (objCNL.value != "" && objCompl.value != "")
		{
			if (objCNL.value + objCompl.value != hdnEstacaoOrigem.value)
			{
				hdnEstacaoOrigem.value = objCNL.value + objCompl.value
				hdnAcao.value = "ResgatarEstacaoOrigem"
				target = "IFrmProcesso2"
				action = "SMBDProcessoSolic.asp"
				submit()
			}	
		}
	}
}

function ResgatarEnderecoEstacao(obj)
{
	with (document.forms[2])
	{
		if (obj.value != ""){
			hdnAcao.value = "ResgatarEnderecoEstacao"
			hdnEstacaoAtual.value = obj.value
			target = "IFrmProcesso2"
			action = "SMBDProcessoSolic.asp"
			submit()
		}
		else{
			spnContEndLocalInstala.innerHTML = ''
			spnTelEndLocalInstala.innerHTML = ''
		}	
	}
}

function ProcurarCliente()
{
	with (document.forms[0])
	{
		if (!IsEmpty(txtRazaoSocial.value))
		{
			hdnAcao.value = "ProcurarCliente"
			target = "IFrmProcesso"
			action = "SMBDProcessoSolic.asp"
			submit()
		}
		else
		{
			alert("Informe a Raz�o Social.")
			return
		}	
	}	
}

function SelProvedorEBT()
{
	with (document.forms[1])
	{
		cboProvedor.value = 11
		hdnAcao.value = "ResgatarPromocaoRegime"
		hdnProvedor.value = 11
		target = "IFrmProcesso"
		action = "ProcessoCla.asp"
		submit()
		cboProvedor.disabled = true
	}
}

function ResgatarPromocaoRegime(obj)
{
	with (document.forms[1])
	{
		if (obj == '[object]'){
			strValue = obj.value
		}
		else{
			strValue = obj
		}
		if (strValue != "")
		{
			hdnAcao.value = "ResgatarPromocaoRegime"
			hdnProvedor.value = strValue
			target = "IFrmProcesso"
			action = "ProcessoCla.asp"
			submit()
		}
		else
		{
			spnRegimeCntr.innerHTML = "<select name=cboRegimeCntr style=width:170px><Option></Option></select>"
			spnPromocao.innerHTML = "<select name=cboPromocao style=width:170px><Option></Option></select>"
		}	
	}
}

//Validar um determinado range
function ValidarRangeCntr(obj,intPosIni,intPosFim,intInterIni,intInterFim)
{
	var strValor = new String("")
	if (obj == '[object]')
		var checkStr = new String(obj.value);
	else
		var checkStr =  new String(obj);
	
	for (var intIndex = 0;intIndex<checkStr.length;intIndex++)
	{
		if (intIndex > parseInt(intPosIni-1) && intIndex < parseInt(intPosFim+1))
		{
			strValor += checkStr.charAt(intIndex);
		}
	}		
	
	if (parseInt(strValor)	< parseInt(intInterIni) || parseInt(strValor)	> parseInt(intInterFim))
	{
		alert("Valor fora do intervalo " + intInterIni + " a " + intInterFim + ".")
		if (obj == '[object]') obj.value = obj.value.substring(0,intPosIni)
		return false
	}
	else
	{
		return true
	}
}

function ProcurarIDFis(intID)
{
	document.forms[1].hdnRazaoSocial.value = document.forms[0].txtRazaoSocial.value
	with (document.forms[1])
	{
		switch (intID)
		{
			case 1:
				hdnIdAcessoFisico.value = ""
				target = "IFrmIDFis1"
				action = "AcessoCompartilhadoSol.asp?intEnd=1"
				submit()
				break
			case 2:	
				hdnIdAcessoFisico1.value = ""
				target = "IFrmIDFis2"
				action = "AcessoCompartilhadoSol.asp?intEnd=2"
				submit()
				break
			case 3: //Editando o Id'F�sico
				target = "IFrmIDFis1"
				action = "AcessoCompartilhadoSol.asp?intEnd=1"
				submit()
				break
		}
	}	
}


function SelIDFisComp(obj,intEnd)
{
	with (document.forms[1])
	{
		hdnIdAcessoFisico.value = obj.value 
		switch (parseInt(intEnd))
		{
			case 1:
				if (rdoPropAcessoFisico[0].checked)
				{
					hdnPropIdFisico.value = rdoPropAcessoFisico[0].value
				}
				if (rdoPropAcessoFisico[1].checked)
				{
					hdnPropIdFisico.value = rdoPropAcessoFisico[1].value
				}
				if (rdoPropAcessoFisico[2].checked)
				{
					hdnPropIdFisico.value = rdoPropAcessoFisico[2].value
				}
				hdnAecIdFis.value = obj.Aec_IdFis
				break
			case 2:	
				if (rdoPropAcessoFisico[0].checked)
				{
					hdnPropIdFisico1.value = rdoPropAcessoFisico[0].value
				}
				if (rdoPropAcessoFisico[1].checked)
				{
					hdnPropIdFisico1.value = rdoPropAcessoFisico[1].value
				}
				if (rdoPropAcessoFisico[2].checked)
				{
					hdnPropIdFisico1.value = rdoPropAcessoFisico[3].value
				}
				break
		}	

		switch (parseInt(intEnd))
		{
			case 1:
				hdnIdAcessoFisico.value=obj.value
				//hdnPropIdFisico.value = obj.prop
				//Verifica se o usu�rio quer compartilhar ou n�o o ID F�sico selecionado 
				hdnCompartilhamento.value = "0"
				hdnAcao.value = "AutorizarCompartilhamento"
				hdnSubAcao.value = "IdFisEndInstala"
				target = "IFrmProcesso"
				action = "ProcessoCla.asp"
				submit()

				break
			case 2:	
				hdnIdAcessoFisico1.value=obj.value
				//hdnPropIdFisico1.value = obj.prop
				//Verifica se o usu�rio quer compartilhar ou n�o o ID F�sico selecionado
				hdnCompartilhamento1.value = "0"
				hdnAcao.value = "AutorizarCompartilhamento"
				hdnSubAcao.value = "IdFisEndPtoInterme"
				target = "IFrmProcesso"
				action = "ProcessoCla.asp"
				submit()
				break
		}
	}	
}

function ReenviarSolicitacao(intRetASP,intRetJS)
{
	with (document.forms[1])
	{
		switch (parseInt(intRetASP))
		{
			case 138: //Endereco de instala��o
				switch (parseInt(intRetJS))
				{
					case 1: //Aceito
						hdnCompartilhamento.value = "1"
						//Resgatar demais campos do Id F�sico
						//hdnAecIdFis j� foi populado no onClick do Radio button fun��o SelIDFisComp()
						hdnAcao.value = "ResgatarAcessoFisComp"
						target = "IFrmProcesso"
						action = "SMBDProcessoSolic.asp"
						submit()
						break
					
					case 2: // N�o Aceito
						hdnIdAcessoFisico.value = ""
						hdnPropIdFisico.value  = ""
						hdnCompartilhamento.value = "0"
						btnIDFis1.focus()
						limparIDFisico(1)
						break
				}
				break
		
			case 139: //Endereco do ponto intermedi�rio
				switch (parseInt(intRetJS))
				{
					case 1: //Aceito
						hdnCompartilhamento1.value = "1"
						break
					
					case 2: // N�o Aceito
						hdnIdAcessoFisico1.value = ""
						hdnPropIdFisico1.value  = ""
						hdnCompartilhamento1.value = "0"
						btnIDFis2.focus()
						limparIDFisico(2)
						break
				}
				break
		}	
	}
}

function limparIDFisico(intID)
{
	switch (parseInt(intID))
	{
		case 1:
			with (IFrmIDFis1.document.forms[0])
			{
				if (rdoIDFis1 == '[object]')
				{
					rdoIDFis1.checked = false
					try{
						parent.document.Form2.hdnNovoPedido.value = ""
					}catch(e){}	
				}
				for (var intIndex=0;intIndex<rdoIDFis1.length;intIndex++)
				{
					rdoIDFis1[intIndex].checked = false	
					try{
						parent.document.Form2.hdnNovoPedido.value = ""
					}catch(e){}		
				}
			}	
			break

		case 2:
			with (IFrmIDFis2.document.forms[0])
			{
				if (rdoIDFis2 == '[object]')
				{
					rdoIDFis2.checked = false
				}
				for (var intIndex=0;intIndex<rdoIDFis2.length;intIndex++)
				{
					rdoIDFis2[intIndex].checked = false	
				}
			}	
			break
	}	
}

function Gravar()
{
	with (document.forms[0])
	{
		if (!ValidarCampos(txtRazaoSocial,"Nome do Cliente/Raz�o Social")) return
		if (!ValidarCampos(txtNomeFantasia,"Nome Fantasia")) return
		if (!ValidarCampos(txtContaSev,"Conta Corrente")) return
		if (!ValidarCampos(txtSubContaSev,"Sub Conta")) return

		if (!IsEmpty(cboSistemaOrderEntry.value))
		{
			if (IsEmpty(txtOrderEntry[0].value) || IsEmpty(txtOrderEntry[1].value) || IsEmpty(txtOrderEntry[2].value))
			{ 
				alert("Order Entry incompleta.Favor preencher Sistema/Ano/Nro/Item.")
				cboSistemaOrderEntry.focus()
				return
			}
			else
			{	
				if (parseInt(txtOrderEntry[0].value) < 1964)
				{
					alert("Ano da Order Entry inv�lido. Ano dever ser maior ou igual a 1964.")
					return
				}
				else
				{
					hdnOrderEntry.value = cboSistemaOrderEntry.value + txtOrderEntry[0].value + txtOrderEntry[1].value + txtOrderEntry[2].value
				}	
			}	
		}	
		if (!MontarDesigServico()) return
		if (!ValidarCampos(cboServicoPedido,"Servi�o")) return
		if (!ValidarCampos(cboVelServico,"Velocidade do Servi�o")) return
		if (!ValidarCampos(txtNroContrServico,"N� do Contrato Servi�o")) return

		//Designa��o do Acesso Principal
		hdnDesigAcessoPri.value = ""
		if (txtDesigAcessoPri.value != "" && txtDesigAcessoPri.value.length < 7)
		{
			alert("Designa��o do Acesso Principal(678) fora de padr�o 678N7.")
			txtDesigAcessoPri.focus()
			return
		}
		
		if (txtDesigAcessoPri.value != "" && txtDesigAcessoPri.value.length == 7)
		{
			hdnDesigAcessoPri.value = txtDesigAcessoPri0.value + txtDesigAcessoPri.value
		}
	}
	//Verifica se tem acesso adicionado
	var objNode = objXmlGeral.selectNodes("//xDados/Acesso")
	if (objNode.length == 0){
		//alert("Informa��es do Acesso s�o Obrigat�rias.")
		if (!AdicionarAcessoLista(true)) return
		if (document.Form2.rdoPropAcessoFisico[1].checked)
		{
			ContinuarGravacao()
		}else
		{
			ResgatarGLA(true)
		}	
	}else
	{
		ContinuarGravacao()
	}

}

function ContinuarGravacao()
{
	var objNodeAux = objXmlGeral.selectNodes("//Acesso[cboTipoPonto='I']")
	if (objNodeAux.length == 0){
		alert("� necess�rio pelo menos um ponto de instala��o.")
		return
	}


	with (document.forms[2]) //Form3
	{

		var blnAchouSatelite = false
		if (!ValidarCampos(cboLocalEntrega,"Esta��o do Local de Entrega")) return
		if (!ValidarCampos(cboLocalConfig,"Esta��o do Local de Configura��o")) return

		var objNode = objXmlGeral.selectNodes("//xDados/Acesso")
		if (objNode.length == 1){
			for (var intIndex=0;intIndex<objNode.length;intIndex++){
				var intChave = objNode[intIndex].childNodes[0].text
				var intTec = RequestNodeAcesso(objXmlGeral,"cboTecnologia",intChave)
				if (intTec == 4) blnAchouSatelite = true
			}
		}	
		if (!blnAchouSatelite){
			//if (!ValidarCampos(cboInterfaceEbt,"Interface EBT")) return
		}	
		if (!ValidarCampos(cboOrgao,"Org�o")) return
		if (IsEmpty(hdntxtGICN.value)){alert('GIC-N � um campo obrigat�rio.');txtGICN.focus();return}

	}

	document.Form4.hdnXml.value = ""
	for (var intIndex=0;intIndex<document.Form1.elements.length;intIndex++){
		var elemento = document.Form1.elements[intIndex];
		if (elemento.type != 'button'){
			AdicionarNode(objXmlGeral,elemento.name,elemento.value)
		}	
	}
	//Outros campos
	AdicionarNode(objXmlGeral,"hdnServico",document.Form1.cboServicoPedido.value)
	if (document.Form3.txtGICL.value != "")	AdicionarNode(objXmlGeral,"txtGICL",document.Form3.txtGICL.value)
	if (document.Form3.txtGLA.value != "")	AdicionarNode(objXmlGeral,"txtGLA",document.Form3.txtGLA.value)
	if (document.Form3.txtGLAE.value != "")	AdicionarNode(objXmlGeral,"txtGLAE",document.Form3.txtGLAE.value)

	//Tipo do Contrato
	if (document.forms[0].rdoNroContrato[0].checked) AdicionarNode(objXmlGeral,"intTipoContrato",1)
	if (document.forms[0].rdoNroContrato[1].checked) AdicionarNode(objXmlGeral,"intTipoContrato",2)
	if (document.forms[0].rdoNroContrato[2].checked) AdicionarNode(objXmlGeral,"intTipoContrato",3)

	for (var intIndex=0;intIndex<document.Form3.elements.length;intIndex++){
		var elemento = document.Form3.elements[intIndex];
		if (elemento.type != 'button'){
			AdicionarNode(objXmlGeral,elemento.name,elemento.value)
		}	
	}
	//Verifica se o usu�rio editou e n�o atualizou a lista
	if (AcessoAlteradoNaoAtualizado()){
		var intRet=alertbox('As informa��es do acesso atualmente editado foram alteradas. Deseja atualiz�-la e prosseguir com a grava��o da solicita��o?','Sim','N�o','Sair')
		switch (parseInt(intRet))
		{
			case 1:
				if (!AdicionarAcessoLista(true)) return
				break
			case 3:
				return
				break
		}		
	}

	with (document.Form4){
		if (hdnTipoAcao.value == "Alteracao")
		{
			/*
			var objNodeComp = objXmlGeral.selectNodes("//Acesso[hdnCompartilhamento=0]")
			//Deve ser apresentada a tela de taxa de servi�o
			if (hdnVelIdServicoOld.value != document.Form1.cboVelServico.value && objNodeComp.length > 0)
			{
				var objNodeComp = objXmlGeral.selectNodes("//Acesso[hdnCompartilhamento=1]")
				var strIdAcessoFisComp = new String("")
				for (var intIndex=0;intIndex<objNodeComp.length;intIndex++)
				{
					strIdAcessoFisComp += objNodeComp[intIndex].getElementsByTagName("Acf_Id").item(0).text
					if (intIndex<parseInt(objNodeComp.length-1)) strIdAcessoFisComp += ","
				}	
				
				if (strIdAcessoFisComp != "")
				{
					var strAry = hdnIdAcessoLogico.value+","+hdnSolId.value+","+hdnTipoProcesso.value + "," + strIdAcessoFisComp
					var objAry = strAry.split(",")
				}else
				{
					var objAry = new Array(hdnIdAcessoLogico.value,hdnSolId.value,hdnTipoProcesso.value)
				}	
				//var objAry = new Array(hdnIdAcessoLogico.value,hdnSolId.value,hdnTipoProcesso.value)
				var objXmlTaxaServico = window.showModalDialog('AlteracaoTaxaServico.asp',objAry,'dialogHeight: 300px; dialogWidth: 600px; dialogTop: px; dialogLeft: px; edge: Raised; center: Yes; help: No; resizable: No; status: No;');
				var objNode = objXmlTaxaServico.selectNodes("//Ret")
				if (objNode.length > 0 )
				{
					if (objNode[0].childNodes[0].text != 999)
					{
						AddTaxaServico(objXmlGeral,objXmlTaxaServico)
					}
					else
					{
						return
					}	
				}else
				{
					return
				}
			}
			*/
			hdnAcao.value = "Alteracao"
		}else
		{
			hdnAcao.value = "GravarSolicitacao"
		} 
		hdnXml.value = objXmlGeral.xml
		target = "IFrmProcesso"
		action = "SMBDProcessoSolic.asp"
		submit()
	}	

}

function NovoPedido(obj)
{
	if (obj.checked){
		document.Form2.hdnNovoPedido.value = 1
	}else{
		document.Form2.hdnNovoPedido.value = ""
	}	
}
function AdicionarAcessoLista(){

	with (document.forms[1]) //Form2
	{
		var blnAchou = false
		for (var intIndex=0;intIndex<rdoPropAcessoFisico.length;intIndex++)
		{
			if (rdoPropAcessoFisico[intIndex].checked)
			{
				blnAchou = true
			}
		}
		if (!blnAchou)
		{
			alert("Propriet�rio do Acesso F�sico � um Campo Obrigat�rio.")	
			rdoPropAcessoFisico[0].focus()
			return false
		}

		if ((rdoPropAcessoFisico[1].checked) && (cboTecnologia.value == ""))
		{
			alert("Tecnologia � um Campo Obrigat�rio.")	
			cboTecnologia.focus();
			return false
		}

		var objNodeAux = objXmlGeral.selectNodes("//Acesso[cboTipoPonto='I' && TipoAcao != 'R']")
		if (objNodeAux.length == 1 && cboTipoPonto.value == 'I'){
			if (objNodeAux[0].childNodes[0].text != hdnIntIndice.value && !ValidarPontoInstalacao()){
				alert("N�o � poss�vel adicionar mais que um Ponto de Instala��o para endere�os diferentes.")
				return false
			}	
		}

		if (!ValidarCampos(cboVelAcesso,"Velocidade do Acesso F�sico")) return false

		//if (rdoPropAcessoFisico[1].checked && parseInt("0"+cboTecnologia.value) != 3)
		//{
		//	if (!ValidarCampos(cboRegimeCntr,"Para EBT com a Tecnologia Difente de ADE o Prazo de Contrata��o de //Acesso")) return false
//		}

		var strVel = cboVelAcesso[cboVelAcesso.selectedIndex].text
		if (strVel == "2M" || strVel == "34M" || strVel == "155M" || strVel == "622M"){
			if (!ValidarCampos(cboTipoVel,"Para as Velocidades de 2M/34M/155M/622M o Tipo de Velocidade")) return false
		}
		if (!ValidarCampos(txtQtdeCircuitos,"Quantidade de Circuitos")) return false
		if (txtQtdeCircuitos.value == 0){alert("Quantidade de Circuitos dever ser maior ou igual a um.");return false}
		if (!ValidarCampos(cboProvedor,"Provedor")) return false
		//Endere�o do Acesso F�sico
		//Endere�o Origem
		if (!ValidarCampos(cboUFEnd,"Estado Origem")) return false
		if (!ValidarCampos(txtEndCid,"Cidade Origem")) return false
		if (!ValidarCampos(cboLogrEnd,"Logradouro Origem")) return false
		if (!ValidarCampos(txtEnd,"Nome do Logradouro Origem")) return false
		if (!ValidarCampos(txtNroEnd,"N�mero Origem")) return false
		if (!ValidarCampos(txtBairroEnd,"Bairro Origem")) return false
		if (!ValidarCampos(txtCepEnd,"CEP Origem")) return false
		if (!ValidarTipoInfo(txtCepEnd,2,"CEP Origem")) return false
		//Endere�o Destino
		/*
		if (!ValidarCampos(cboUFEndDest,"Estado Destino")) return false
		if (!ValidarCampos(txtEndCidDest,"Cidade Destino")) return false
		if (!ValidarCampos(cboLogrEndDest,"Logradouro Destino")) return false
		if (!ValidarCampos(txtEndDest,"Nome do Logradouro Destino")) return false
		if (!ValidarCampos(txtNroEndDest,"N�mero Destino")) return false
		if (!ValidarCampos(txtBairroEndDest,"Bairro Destino")) return false
		if (!ValidarCampos(txtCepEndDest,"CEP Destino")) return false
		if (!ValidarTipoInfo(txtCepEndDest,2,"CEP Destino")) return false
		*/

		if (!ValidarCampos(txtContatoEnd,"Contato")) return false
		if (!ValidarCampos(txtTelEndArea,"Telefone")) return false
		if (txtTelEndArea.value.length != 2)
		{ 
			alert("C�digo de area do telefone inv�lido.")
			txtTelEndArea.focus()
			return false
		}	
		if (!ValidarCampos(txtTelEnd,"Telefone")) return false
		if (!ValidarCampos(txtCNPJ,"CNPJ do Endere�o de Instala��o")) return false
		if (!VerificarCpfCnpj(txtCNPJ,2)) return false
		
		if (!ValidarCampos(cboTipoPonto,"Tipo do Ponto(Instala��o/Intermedi�rio)")) return false

		if (rdoPropAcessoFisico[1].checked && parseInt("0"+cboTecnologia.value) != 4)
		{
			if (!ValidarCampos(cboInterFaceEnd,"Interface")) return false
		}
		else
		{
			if (rdoPropAcessoFisico[0].checked || rdoPropAcessoFisico[2].checked)
			{
				if (!ValidarCampos(cboInterFaceEnd,"Interface")) return false
				if (!ValidarCampos(cboInterFaceEndFis,"Interface")) return false
			}
		}
		
		if (rdoPropAcessoFisico[1].checked && (parseInt("0"+cboTecnologia.value) == 1))
		{
			//Verificar se existe o compartinhamento de ID'F�sico
			if (cboTipoPonto.value = "I"){
				//if (!ValidarCampos(txtCNLSiglaCentroCliDest,"Destino")) return false;
				//if (!ValidarCampos(txtComplSiglaCentroCliDest,"Complemento do Destino")) return false;
			}else
			{
				if (!ValidarCampos(txtCNLSiglaCentroCli,"Origem")) return false;
				if (!ValidarCampos(txtComplSiglaCentroCli,"Complemento da Origem")) return false;
				//if (!ValidarCampos(txtCNLSiglaCentroCliDest,"Destino")) return false;
				//if (!ValidarCampos(txtComplSiglaCentroCliDest,"Complemento do Destino")) return false;
			}	
		}	

		var blnMessage = false
		if (arguments.length>0){
			blnMessage = arguments[0]
			intRet = 1
		}
		if (!blnMessage){
			var intRet=alertbox('Deseja permanecer com os dados?','Sim','N�o','Sair')
		}	
		switch (parseInt(intRet))
		{
			case 1:
				xmlUpd(false)
				updOrdemXml()
				AtualizarLista()
				//Para o compartilhamento
				try{
					ReenviarSolicitacao(138,2)//limpa o acesso f�sico compartilhado
					divIDFis1.style.display = 'none'
					spnBtnLimparIdFis1.innerHTML =''
					AdicionarNode(objXmlGeral,"hdnCompartilhamento",document.Form2.hdnCompartilhamento.value)
					AdicionarNode(objXmlGeral,"hdnIdAcessoFisico",document.Form2.hdnIdAcessoFisico.value)
					AdicionarNode(objXmlGeral,"hdnNovoPedido",document.Form2.hdnNovoPedido.value)
					Form2.hdnNovoPedido.value = ""
				}catch(e){}	
				break		
			case 2:
				xmlUpd(true)
				updOrdemXml()
				AtualizarLista()
				TipoOrigem("T")
				//Para o compartilhamento
				try{
					ReenviarSolicitacao(138,2)//limpa o acesso f�sico compartilhado
					divIDFis1.style.display = 'none'
					spnBtnLimparIdFis1.innerHTML =''
					AdicionarNode(objXmlGeral,"hdnCompartilhamento",document.Form2.hdnCompartilhamento.value)
					AdicionarNode(objXmlGeral,"hdnIdAcessoFisico",document.Form2.hdnIdAcessoFisico.value)
					AdicionarNode(objXmlGeral,"hdnNovoPedido",document.Form2.hdnNovoPedido.value)
					Form2.hdnNovoPedido.value = ""
				}catch(e){}	
				break
		}

		DesabilitarCamposAlt(false,"")

		rdoPropAcessoFisico[0].focus()
		ResgatarGLA()
	}
	document.Form2.btnAddAcesso.value = "Adicionar"
	return true
}	

function AtualizarAcessoListaSMBD(){

	with (document.forms[1]) //Form2
	{

		if (hdnIntIndice.value == ""){
			alert("Selecione um item da lista para alterar.")
			return false
		}
		var blnAchou = false
		for (var intIndex=0;intIndex<rdoPropAcessoFisico.length;intIndex++)
		{
			if (rdoPropAcessoFisico[intIndex].checked)
			{
				blnAchou = true
			}
		}
		if (!blnAchou)
		{
			alert("Propriet�rio do Acesso F�sico � um Campo Obrigat�rio.")	
			rdoPropAcessoFisico[0].focus()
			return false
		}

		if ((rdoPropAcessoFisico[1].checked) && (cboTecnologia.value == ""))
		{
			alert("Tecnologia � um Campo Obrigat�rio.")	
			cboTecnologia.focus();
			return false
		}

		var objNodeAux = objXmlGeral.selectNodes("//Acesso[cboTipoPonto='I' && TipoAcao != 'R']")
		if (objNodeAux.length == 1 && cboTipoPonto.value == 'I'){
			if (objNodeAux[0].childNodes[0].text != hdnIntIndice.value && !ValidarPontoInstalacao()){
				alert("N�o � poss�vel adicionar mais que um Ponto de Instala��o para endere�os diferentes.")
				return false
			}	
		}

		if (!ValidarCampos(cboVelAcesso,"Velocidade do Acesso F�sico")) return false

		//if (rdoPropAcessoFisico[1].checked && parseInt("0"+cboTecnologia.value) != 3)
		//{
		//	if (!ValidarCampos(cboRegimeCntr,"Para EBT com a Tecnologia Difente de ADE o Prazo de Contrata��o de //Acesso")) return false
//		}

		var strVel = cboVelAcesso[cboVelAcesso.selectedIndex].text
		if (strVel == "2M" || strVel == "34M" || strVel == "155M" || strVel == "622M"){
			if (!ValidarCampos(cboTipoVel,"Para as Velocidades de 2M/34M/155M/622M o Tipo de Velocidade")) return false
		}
		if (!ValidarCampos(txtQtdeCircuitos,"Quantidade de Circuitos")) return false
		if (txtQtdeCircuitos.value == 0){alert("Quantidade de Circuitos dever ser maior ou igual a um.");return false}
		if (!ValidarCampos(cboProvedor,"Provedor")) return false
		//Endere�o do Acesso F�sico
		//Endere�o Origem
		if (!ValidarCampos(cboUFEnd,"Estado Origem")) return false
		if (!ValidarCampos(txtEndCid,"Cidade Origem")) return false
		if (!ValidarCampos(cboLogrEnd,"Logradouro Origem")) return false
		if (!ValidarCampos(txtEnd,"Nome do Logradouro Origem")) return false
		if (!ValidarCampos(txtNroEnd,"N�mero Origem")) return false
		if (!ValidarCampos(txtBairroEnd,"Bairro Origem")) return false
		if (!ValidarCampos(txtCepEnd,"CEP Origem")) return false
		if (!ValidarTipoInfo(txtCepEnd,2,"CEP Origem")) return false
		//Endere�o Destino
		/*
		if (!ValidarCampos(cboUFEndDest,"Estado Destino")) return false
		if (!ValidarCampos(txtEndCidDest,"Cidade Destino")) return false
		if (!ValidarCampos(cboLogrEndDest,"Logradouro Destino")) return false
		if (!ValidarCampos(txtEndDest,"Nome do Logradouro Destino")) return false
		if (!ValidarCampos(txtNroEndDest,"N�mero Destino")) return false
		if (!ValidarCampos(txtBairroEndDest,"Bairro Destino")) return false
		if (!ValidarCampos(txtCepEndDest,"CEP Destino")) return false
		if (!ValidarTipoInfo(txtCepEndDest,2,"CEP Destino")) return false
		*/

		if (!ValidarCampos(txtContatoEnd,"Contato")) return false
		if (!ValidarCampos(txtTelEndArea,"Telefone")) return false
		if (txtTelEndArea.value.length != 2)
		{ 
			alert("C�digo de area do telefone inv�lido.")
			txtTelEndArea.focus()
			return false
		}	
		if (!ValidarCampos(txtTelEnd,"Telefone")) return false
		if (!ValidarCampos(txtCNPJ,"CNPJ do Endere�o de Instala��o")) return false
		if (!VerificarCpfCnpj(txtCNPJ,2)) return false
		
		if (!ValidarCampos(cboTipoPonto,"Tipo do Ponto(Instala��o/Intermedi�rio)")) return false

		if (rdoPropAcessoFisico[1].checked && parseInt("0"+cboTecnologia.value) != 4)
		{
			if (!ValidarCampos(cboInterFaceEnd,"Interface")) return false
		}
		else
		{
			if (rdoPropAcessoFisico[0].checked || rdoPropAcessoFisico[2].checked)
			{
				if (!ValidarCampos(cboInterFaceEnd,"Interface")) return false
				if (!ValidarCampos(cboInterFaceEndFis,"Interface")) return false
			}
		}
		
		if (rdoPropAcessoFisico[1].checked && (parseInt("0"+cboTecnologia.value) == 1))
		{
			//Verificar se existe o compartinhamento de ID'F�sico
			if (cboTipoPonto.value = "I"){
				if (!ValidarCampos(txtCNLSiglaCentroCli,"CNL da Sigla do Centro do Cliente")) return false;
				if (!ValidarCampos(txtComplSiglaCentroCli,"Complemento da Sigla do Centro do Cliente")) return false;
				//if (!ValidarCampos(txtCNLSiglaCentroCliDest,"Destino")) return false;
				//if (!ValidarCampos(txtComplSiglaCentroCliDest,"Complemento do Destino")) return false;
			}else
			{
				if (!ValidarCampos(txtCNLSiglaCentroCli,"Origem")) return false;
				if (!ValidarCampos(txtComplSiglaCentroCli,"Complemento da Origem")) return false;
				//if (!ValidarCampos(txtCNLSiglaCentroCliDest,"Destino")) return false;
				//if (!ValidarCampos(txtComplSiglaCentroCliDest,"Complemento do Destino")) return false;
			}	
		}	

		var blnMessage = false
		if (arguments.length>0){
			blnMessage = arguments[0]
			intRet = 1
		}
		if (!blnMessage){
			var intRet=alertbox('Deseja permanecer com os dados?','Sim','N�o','Sair')
		}	
		switch (parseInt(intRet))
		{
			case 1:
				xmlUpd(false)
				updOrdemXml()
				AtualizarLista()
				//Para o compartilhamento
				try{
					ReenviarSolicitacao(138,2)//limpa o acesso f�sico compartilhado
					divIDFis1.style.display = 'none'
					spnBtnLimparIdFis1.innerHTML =''
					AdicionarNode(objXmlGeral,"hdnCompartilhamento",document.Form2.hdnCompartilhamento.value)
					AdicionarNode(objXmlGeral,"hdnIdAcessoFisico",document.Form2.hdnIdAcessoFisico.value)
					AdicionarNode(objXmlGeral,"hdnNovoPedido",document.Form2.hdnNovoPedido.value)
					Form2.hdnNovoPedido.value = ""
				}catch(e){}	
				break		
			case 2:
				xmlUpd(true)
				updOrdemXml()
				AtualizarLista()
				TipoOrigem("T")
				//Para o compartilhamento
				try{
					ReenviarSolicitacao(138,2)//limpa o acesso f�sico compartilhado
					divIDFis1.style.display = 'none'
					spnBtnLimparIdFis1.innerHTML =''
					AdicionarNode(objXmlGeral,"hdnCompartilhamento",document.Form2.hdnCompartilhamento.value)
					AdicionarNode(objXmlGeral,"hdnIdAcessoFisico",document.Form2.hdnIdAcessoFisico.value)
					AdicionarNode(objXmlGeral,"hdnNovoPedido",document.Form2.hdnNovoPedido.value)
					Form2.hdnNovoPedido.value = ""
				}catch(e){}	
				break
		}

		DesabilitarCamposAlt(false,"")

		rdoPropAcessoFisico[0].focus()
		ResgatarGLA()
	}
	document.Form2.btnAddAcesso.value = "Atualizar"
	return true
}	

function DesabilitarCamposAlt(blnAcao,intChave)
{
	try{
		var	objNode = objXmlGeral.selectNodes("//xDados/Acesso[intIndice="+parseInt(intChave)+"]")

		if (document.forms[1].hdnTipoProcesso.value == "3")//Tipo Altera��o
		{
			if (intChave != "")
			{
				if (objNode.length > 0)
				{
					var strTipoAcao = objNode[0].getElementsByTagName("TipoAcao").item(0).text
					if (strTipoAcao != "N")
					{
						document.forms[1].rdoPropAcessoFisico[0].disabled = blnAcao
						document.forms[1].rdoPropAcessoFisico[1].disabled = blnAcao
						document.forms[1].rdoPropAcessoFisico[2].disabled = blnAcao
						document.forms[1].cboProvedor.disabled = blnAcao
					}else{
						if (intComp == "1")
						{
							document.forms[1].rdoPropAcessoFisico[0].disabled = blnAcao
							document.forms[1].rdoPropAcessoFisico[1].disabled = blnAcao
							document.forms[1].rdoPropAcessoFisico[2].disabled = blnAcao
							document.forms[1].cboProvedor.disabled = blnAcao
						}	
					}	
				}	
			}else{
				document.forms[1].rdoPropAcessoFisico[0].disabled = blnAcao
				document.forms[1].rdoPropAcessoFisico[1].disabled = blnAcao
				document.forms[1].rdoPropAcessoFisico[2].disabled = blnAcao
				document.forms[1].cboProvedor.disabled = blnAcao
			}
		}
	}catch(e){}
}

function RemoverAcessoLista(){

	with (document.forms[1]){
		DesabilitarCamposAlt(false,hdnIntIndice.value)
		if (hdnIntIndice.value != ""){
			RemoverAcesso(hdnIntIndice.value,true)
			LimparInfoAcesso()
			updOrdemXml()
			AtualizarLista()
			rdoPropAcessoFisico[0].focus()			
			ResgatarGLA()
			try{
				ReenviarSolicitacao(138,2)//limpa o acesso f�sico compartilhado
				divIDFis1.style.display = 'none'
				spnBtnLimparIdFis1.innerHTML =''
			}catch(e){}
			btnAddAcesso.value = "Adicionar"
		}
		else{
			alert("Selecione um item para remover em \"Acesso Adicionados\".")
			return
		}
	}
}

function EditarAcessoLista(objChave){
	with (document.Form2){
		hdnChaveAcessoFis.value = objChave.value
		hdnTecnologia.value = RequestNodeAcesso(objXmlGeral,"cboTecnologia",objChave.value)
		hdnVelAcessoFisSel.value = RequestNodeAcesso(objXmlGeral,"cboVelAcesso",objChave.value)
		hdnProvedor.value = RequestNodeAcesso(objXmlGeral,"cboProvedor",objChave.value)
		strPropAcesso = RequestNodeAcesso(objXmlGeral,"rdoPropAcessoFisico",objChave.value)
		TipoOrigem(RequestNodeAcesso(objXmlGeral,"cboTipoPonto",objChave.value))
		document.Form2.btnAddAcesso.value = "Alterar"

		try{
			ReenviarSolicitacao(138,2)//limpa o acesso f�sico compartilhado
			divIDFis1.style.display = 'none'
			spnBtnLimparIdFis1.innerHTML =''
		}catch(e){}

		if (strPropAcesso == "EBT")
		{
			divTecnologia.style.display = ""
		}
		else
		{
			if (divTecnologia.style.display == "")
			{
				cboTecnologia.value = ""
				divTecnologia.style.display = "none"
			}	
		}
		var strVel = RequestNodeAcesso(objXmlGeral,"cboVelAcessoText",objChave.value)
		if (strVel == "2M" || strVel == "34M" || strVel == "155M" || strVel == "622M"){
			divTipoVel.style.display = ""
		}else{
			cboTipoVel.value = ""
			divTipoVel.style.display = "none"
		}	
		//Sinaliza que o id f�sico esta compartinhado par uma edi��o
		hdnNodeCompartilhado.value = RequestNodeAcesso(objXmlGeral,"hdnCompartilhamento",objChave.value)
		hdnCompartilhamento.value = RequestNodeAcesso(objXmlGeral,"hdnCompartilhamento",objChave.value)
		hdnNovoPedido.value = RequestNodeAcesso(objXmlGeral,"hdnNovoPedido",objChave.value)
 		
		hdnAcao.value = "EditarAcessoFisico"
		target = "IFrmProcesso"
		action = "ProcessoCla.asp"
		submit()
	}
}	 

function LimparInfoAcesso(){

	try
	{
		document.forms[1].rdoPropAcessoFisico[0].disabled = false
		document.forms[1].rdoPropAcessoFisico[1].disabled = false
		document.forms[1].rdoPropAcessoFisico[2].disabled = false
		document.forms[1].cboProvedor.disabled = false
		document.Form2.btnAddAcesso.value = "Adicionar"
		document.Form2.hdnCNLAtual.value = ""
		document.Form2.hdnCNLAtual1.value = ""
		document.Form2.hdnEstacaoOrigem.value = ""
		document.Form2.hdnEstacaoDestino.value = ""
	}catch(e){}	

	TipoOrigem("T")

	for (var intIndex=0;intIndex<document.Form2.elements.length;intIndex++)
	{
		var elemento = document.Form2.elements[intIndex];
		if (elemento.type != 'button' && elemento.type != 'hidden' && elemento.type != 'radio')	elemento.value = ""
		if (elemento.type == 'radio')
		{
			elemento.checked = false
		}
	}
	for (var intIndexII=0;intIndexII<IFrmAcessoFis.document.Form1.elements.length;intIndexII++)
	{
		var elemento = IFrmAcessoFis.document.Form1.elements[intIndexII];
		if (elemento.type == 'radio')
		{
			elemento.checked = false
		}
	}
	try{
		ReenviarSolicitacao(138,2)//limpa o acesso f�sico compartilhado
		divIDFis1.style.display = 'none'
		spnBtnLimparIdFis1.innerHTML =''
	}catch(e){}

	document.Form2.cboProvedor.disabled = false 
	document.Form2.hdnIntIndice.value = "" //Chave para poder adicionar um novo
	document.Form2.txtQtdeCircuitos.value = 1
	divTecnologia.style.display = "none"
	document.Form2.cboTipoVel.value = ""
	divTipoVel.style.display = "none"
	document.Form2.rdoPropAcessoFisico[0].focus()
	parent.spnListaIdFis.innerHTML = ""
}

//Atualiza a ordem de entrada para o xml
function updOrdemXml(){
 var objNode = objXmlGeral.selectNodes("//Acesso")
 if (objNode.length > 0){
	for (var intIndex=0;intIndex<objNode.length;intIndex++){
		intChave = objNode[intIndex].childNodes[0].text
		AdicionarNodeAcesso(objXmlGeral,"intOrdem",parseInt(intIndex+1),intChave)
	}
 }
}

function ResgatarTecVel(){
	with (document.forms[1]){
		hdnAcao.value = "ResgatarTecVel"
		target = "IFrmProcesso2"
		action = "ProcessoCla.asp"
		hdnVelAcessoFisSel.value = ""
		if (rdoPropAcessoFisico[0].checked || rdoPropAcessoFisico[2].checked){
			cboTecnologia.value = ""
			submit()
		}else{
			if (cboTecnologia.value != ""){
				submit()				
			}else{
				spnVelAcessoFis.innerHTML = "<Select name=cboVelAcesso style='width:150px'></select>"
			}
		}
		cboVelAcesso.value = ""
		cboTipoVel.value = ""
		divTipoVel.style.display =  "none"
	}
}

function MostrarTipoVel(obj){
	var strVel = obj[obj.selectedIndex].text
	if (strVel == "2M" || strVel == "34M" || strVel == "155M" || strVel == "622M"){
		divTipoVel.style.display = ""
	}else{
		document.Form2.cboTipoVel.value = ""
		divTipoVel.style.display = "none"
	}	
	
}

function ResgatarAcessoFisComp(intChave,objXmlAcessoFisComp)
{
	with (document.Form2)
	{
		hdnChaveAcessoFis.value = intChave
		hdnTecnologia.value = RequestNodeAcesso(objXmlAcessoFisComp,"cboTecnologia",intChave)
		hdnVelAcessoFisSel.value = RequestNodeAcesso(objXmlAcessoFisComp,"cboVelAcesso",intChave)
		hdnProvedor.value = RequestNodeAcesso(objXmlAcessoFisComp,"cboProvedor",intChave)
		strPropAcesso = RequestNodeAcesso(objXmlAcessoFisComp,"rdoPropAcessoFisico",intChave)

		if (strPropAcesso == "EBT")
		{
			divTecnologia.style.display = ""
		}
		else
		{
			if (divTecnologia.style.display == "")
			{
				cboTecnologia.value = ""
				divTecnologia.style.display = "none"
			}	
		}
		var strVel = RequestNodeAcesso(objXmlAcessoFisComp,"cboVelAcessoText",intChave)
		if (strVel == "2M" || strVel == "34M" || strVel == "155M" || strVel == "622M"){
			divTipoVel.style.display = ""
		}else{
			cboTipoVel.value = ""
			divTipoVel.style.display = "none"
		}	
		//Sinaliza que o id f�sico esta compartinhado par uma edi��o
		hdnNodeCompartilhado.value = RequestNodeAcesso(objXmlAcessoFisComp,"hdnCompartilhamento",intChave)
		hdnCompartilhamento.value = RequestNodeAcesso(objXmlAcessoFisComp,"hdnCompartilhamento",intChave)
		hdnNovoPedido.value = RequestNodeAcesso(objXmlAcessoFisComp,"hdnNovoPedido",intChave)
 		
		hdnAcao.value = "EditarAcessoFisComp"
		target = "IFrmProcesso"
		action = "ProcessoCla.asp"
		submit()
	}
}	 


function EditarAcessoFisComp(intChave,objXmlAcessoFisComp)
{
	var	objNode = objXmlAcessoFisComp.selectNodes("//xDados/Acesso[intIndice="+parseInt(intChave)+"]")
	//Refaz a lista de Ids no IFRAME
	for (var intIndex=0;intIndex<objNode.length;intIndex++){
		for (var intIndexII=0;intIndexII<objNode[intIndex].childNodes.length;intIndexII++){
			try{
				//Caso de radio button
				if (objNode[intIndex].childNodes[intIndexII].nodeName == "rdoPropAcessoFisico"){
					eval("document.Form2."+objNode[intIndex].childNodes[intIndexII].nodeName+"["+RequestNodeAcesso(objXmlAcessoFisComp,"rdoPropAcessoFisicoIndex",objNode[intIndex].childNodes[0].text)+"].checked = true")
				}
				else{
					//eval("document.Form2."+objNode[intIndex].childNodes[intIndexII].nodeName+".value='"+objNode[intIndex].childNodes[intIndexII].text+"'")
					var objChildForm = new Object(eval("document.Form2."+objNode[intIndex].childNodes[intIndexII].nodeName))
					//alert(objChildForm.value + " = " + objNode[intIndex].childNodes[intIndexII].nodeName)
					objChildForm.value = objNode[intIndex].childNodes[intIndexII].text
				}	
			}catch(e){}
		}	
	}	

	if (objNode.length > 0)
	{
		var intChaveFis = RequestNodeAcesso(objXmlAcessoFisComp,"Aec_Id",intChave)
		if (intChaveFis == "") intChaveFis = 0
		var objNodeFis = objXmlAcessoFisComp.selectNodes("//xDados/Acesso/IdFisico[Aec_Id="+intChaveFis+"]")
		var strAcessoIdFis =  new String("<table border=0 width=759 cellspacing=0 cellpadding=0>")
		//Refaz a lista de Ids no IFRAME
		for (var intIndex=0;intIndex<objNodeFis.length;intIndex++)
		{
			var intAcfId = objNodeFis[intIndex].childNodes[0].text
			var intAecId = objNodeFis[intIndex].childNodes[2].text
			var objNodePed = objXmlAcessoFisComp.selectNodes("//xDados/Acesso/Pedido[Acf_Id="+intAcfId+"]")
			strAcessoIdFis += "<tr class=clsSilver>"
			strAcessoIdFis += "<td >&nbsp;Pedido</td>"
			strAcessoIdFis += "<td>&nbsp;"+objNodePed[0].childNodes[1].text +"</td>"
			strAcessoIdFis += "<td >&nbsp;ID F�sico</td>"
			strAcessoIdFis += "<td >"
			try{
				strAcessoIdFis +=objNodeFis[intIndex].childNodes[3].text
			}catch(e){}	
			strAcessoIdFis +="</td>"
			strAcessoIdFis += "<td >&nbsp;N� Acesso</td>"
			strAcessoIdFis += "<td >"
			try{
				strAcessoIdFis += objNodeFis[intIndex].childNodes[4].text
			}catch(e){}	
			strAcessoIdFis +="</td>"
			strAcessoIdFis += "</tr>"
			strAcessoIdFis += "<tr></tr>"
		}
		strAcessoIdFis += "</table>"
		//Qtde circuitos
		document.Form2.txtQtdeCircuitos.value = 1
	}
	else{
		strAcessoIdFis = ""
	}	

	//document.Form2.hdnIntIndice.value = intChave //Chave Atual no Html n�o ser� edit�vel mas item novo
	//Acerta o disabled para o provedor quando temos EBT
	if (RequestNodeAcesso(objXmlAcessoFisComp,"rdoPropAcessoFisico",intChave) != "EBT"){
		document.forms[1].cboProvedor.disabled = false
	}
	else{
		document.forms[1].cboProvedor.disabled = true
	}

	DesabilitarCamposAlt(true,intChave)

	parent.spnListaIdFis.innerHTML = strAcessoIdFis
	
}

function TipoOrigem(strTipoOrig)
{
	if (strTipoOrig == "I")
	{
		spnOrigem.innerHTML = "&nbsp;&nbsp;&nbsp;Sigla do Centro do Cliente"
	}else{
		spnOrigem.innerHTML = "&nbsp;&nbsp;&nbsp;Sigla Esta��o Origem"
	}
}