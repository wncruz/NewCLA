/*
�IMPLEMENT SOFT - IMPLEMENTA��ES E SOLU��ES EM INFORM�TICA
	- Sistema			: CLA
	- Arquivo			: ConsultaGeral.js
	- Descri��o			: Fun��es JAVASCRIPT utilizadas na Consulta Geral
*/
//Adicionar,Remove op��es para o combo de campos selecionados
function CarregarCombo(intTipo)
{

	//alert("CarregarCombo")
	with (document.forms[0])
	{

		switch (parseInt(intTipo))
		{
			case 1:
			
				for(var intIndex = 0 ; intIndex < cboCampos.length; intIndex++)
				{
					//Carrega op��es do combo text/value
					if (cboCampos[intIndex].selected)
					{
						if (RequestNode(objXmlGeral,cboCampos[intIndex].value) == "" &&  ValidaSelecao(cboCampos[intIndex].value) )
						{
							var option_combo = new Option(cboCampos[intIndex].text,cboCampos[intIndex].value)
							var option_combo1 = new Option(cboCampos[intIndex].text,cboCampos[intIndex].value)
							cboCamposSel.options[cboCamposSel.length] = option_combo
							cboOrderBy.options[cboOrderBy.length] = option_combo1
							AdicionarNode(objXmlGeral,cboCampos[intIndex].value,cboCampos[intIndex].value)
						}	
					}	
				}
				break

			case 2:
				for(var intIndex = 0 ; intIndex < cboCampos.length; intIndex++)
				{
					if (RequestNode(objXmlGeral,cboCampos[intIndex].value) == "" &&  ValidaSelecao(cboCampos[intIndex].value))
					{
						//Carrega todas as op��es do combo text/value
						var option_combo = new Option(cboCampos[intIndex].text,cboCampos[intIndex].value)
						var option_combo1 = new Option(cboCampos[intIndex].text,cboCampos[intIndex].value)

						cboCamposSel.options[cboCamposSel.length] = option_combo
						cboOrderBy.options[cboOrderBy.length] = option_combo1
						AdicionarNode(objXmlGeral,cboCampos[intIndex].value,cboCampos[intIndex].value)
					}	
				}
				break


			case 3:
				for(var intIndex=parseInt(cboCamposSel.length)-1;intIndex >= 0;intIndex--)
				{
					//Carrega todas as op��es do combo text/value
					if (cboCamposSel[intIndex].selected)
					{
						RemoverNode(objXmlGeral,cboCamposSel[intIndex].value,cboCamposSel[intIndex].value)
						cboCamposSel.remove(intIndex)
						cboOrderBy.remove(intIndex)
					}	
				}
				break

			case 4:
				for(var intIndex = parseInt(cboCamposSel.length)-1; intIndex >= 0; intIndex--)
				{
					RemoverNode(objXmlGeral,cboCamposSel[intIndex].value,cboCamposSel[intIndex].value)
					cboCamposSel.remove(intIndex)
					cboOrderBy.remove(intIndex)
				}
				break
		}	

	}
}

// Abri link com o totem
function LinkTotem (Acf_IDAcessoFisico)
{		
	//alert("LinkTotem")
	with (document.forms[0])
	{

		var strNome = "Facilidade" 
		var objJanela = window.open()
		objJanela.name = strNome
		target = strNome
		action = "http://clclaw5768/crmsf/ConsuCla.asp?idfis=" +  Acf_IDAcessoFisico
		submit() 
	}
}

//Envia dados para a cosulta
function Procurar(objXmlProcurar)
{
	
	//alert("Procurar")
	LimparCosultaGeral(objXmlProcurar, false);

	with (document.forms[0])
	{
		if (cboCamposSel.length == 0)
		{
			//MouseDefault()
			alert("Selecione pelo menos um campo.")
			return
		}
		if (txtNroReg.value == "")
		{
			txtNroReg.value = 10
		}	

		
		if (txtNroReg.value > 100)
		{
			alert("A quantidade maxima de registros � 100.")
	 		txtNroReg.focus()
			return
		}	

		//alert(document.forms[0].hdnSolId.value)
		if (!VerificarFluxo("CLA_Solicitacao.Sol_Id-N-"))
		{
			for (var intIndex=0;intIndex<cboCamposSel.length;intIndex++)
			{
				cboCamposSel[intIndex].selected = true
			}
			
			//alert(document.forms[0].hdnSolId.value)
			if (document.forms[0].hdnSolId.value.length >= 4 )
		    {
				//alert("consulta direta")
				hdnAcao.value = "ProcuraGeral"
				target = "IFrmProcesso"
				action = "ProcessoConsultaGeralDireta.asp"
				submit()
				return(false)
			}
		}
			
		if (VerificarFluxo("CLA_PEDIDO.NUMERODOPEDIDO-A-"))
		{
			if (!Validar(hdnDM)) return

			for (var intIndex=0;intIndex<cboCamposSel.length;intIndex++)
			{
				cboCamposSel[intIndex].selected = true
			}
			
			//PRSS - 09/05/2006  - IN�CIO
			//Otimiza��o da consulta geral: Abrir o registro imediatamente ap�s a cunsulta.
			if (document.forms[0].hdnDM.value.length == 13)
		      {
		      //alert("consulta direta")
			  hdnAcao.value = "ProcuraGeral"
			  target = "IFrmProcesso"
			  action = "ProcessoConsultaGeralDireta.asp"
			  submit()
		      return(false)
		      }
			//PRSS - 09/05/2006 - FIM
									
			hdnAcao.value = "ProcuraGeral"
			target = "IFrmProcesso"
			action = "ProcessoConsultaGeral.asp"
			submit()
		}	
		else	
		{
		
			for (var intIndex=0;intIndex<cboCamposSel.length;intIndex++)
			{
				cboCamposSel[intIndex].selected = true
			}
			hdnAcao.value = "ProcuraGeral";
			target = "IFrmProcesso";
			action = "ProcessoConsultaGeral.asp";
			submit();
		}	
	}
}
	
//Adicionar campos como filtro
function AddFiltro()
{
	
	//alert("AddFiltro")
	var strHtml = new String("")
	var blnAchou = false
	var blnCamposSel = false
	var objAtyTipo
	var strTipo
	var strValida
	var strMaxLen
	var strValidaIII

	with (document.forms[0])
	{
		for(var intIndex = 0 ; intIndex < cboCamposSel.length; intIndex++)
		{
			if (cboCamposSel[intIndex].selected == true)
			{
				if (cboCamposSel[intIndex].value.toUpperCase() == "Cla_Pedido.NumerodoPedido-A-".toUpperCase())
				{
					if (!VerificarFluxo(cboCamposSel[intIndex].value.toUpperCase()))
					{
						var strNomeSpan =  "spn"+Math.round(Math.random()*100000)
						strHtml += "<span id='"+strNomeSpan+"'>"
						strHtml += "<table border=0 width=100% cellspacing=1 cellpadding=0><tr class=clsSilver><td width=200px >"+cboCamposSel[intIndex].text+"</td><td><input type=text size=20 class=text name='"+cboCamposSel[intIndex].value.toUpperCase()+"' value='DM-'  onBlur='AddValorDM(this)' >"
						strHtml += "<input type=button class=button onmouseover=\"showtip(this,event,\'Remover Filtro\') \" style=\'width:15px;BORDER-LEFT-STYLE: none\' name='btnRem"+intIndex+"' value='X' onclick=\"RemoverFiltro('"+strNomeSpan+"','"+cboCamposSel[intIndex].value.toUpperCase()+"')\" >"
						strHtml += "&nbsp;DM-NNNNN/ANO</td></tr></table></span>"
						objAryFiltro[parseInt(objAryFiltro.length+1)] = cboCamposSel[intIndex].value.toUpperCase()
						blnCamposSel = true
					}
					else
					{
						blnAchou = true
					}	
				}
				else
				{
					if (!VerificarFluxo(cboCamposSel[intIndex].value.toUpperCase()))
					{
						
						objAtyTipo = cboCamposSel[intIndex].value.split('-')
						strValida = ""
						strTipo = ""
						strMaxLen = ""
						strValidaII = ""
						strValidaIII = ""
						switch (objAtyTipo[1])
						{
							case "D":
								strTipo = "(dd/mm/aaaa)"
								strValida = 'OnlyNumbers();AdicionaBarraData(this)'
								strValidaII = 'if (!ValidarTipoInfo(this,1,"'+cboCamposSel[intIndex].text+'")){this.focus()}'
								strMaxLen = " maxlength=10 "
								break
							case "N":	
								strValidaIII = 'ValidarTipo(this,0);'
								break
						}

						var strNomeSpan =  "spn"+Math.round(Math.random()*100000)
						strHtml += "<span id='"+strNomeSpan+"'>"
						strHtml += "<table border=0 width=100% cellspacing=1 cellpadding=0><tr class=clsSilver><td width=200px >"+cboCamposSel[intIndex].text+"</td><td>"
						strHtml += "<input type=text class=text size=20 "+strMaxLen+" name='"+cboCamposSel[intIndex].value.toUpperCase()+"' onKeyPress=\'"+strValida+"\' onBlur=\'"+strValidaII+"\' onKeyUp=\'"+strValidaIII+"\' >"
						strHtml += "<input type=button class=button onmouseover=\"showtip(this,event,\'Remover Filtro\') \" style=\'width:15px;BORDER-LEFT-STYLE: none\' name='btnRem"+intIndex+"' value='X' onclick=\"RemoverFiltro('"+strNomeSpan+"','"+cboCamposSel[intIndex].value.toUpperCase()+"')\" >"
						strHtml += "&nbsp;"+strTipo+"</td></tr></table>"
						strHtml += "</span>"
						objAryFiltro[parseInt(objAryFiltro.length)] = cboCamposSel[intIndex].value.toUpperCase()
						blnCamposSel = true
					}
					else
					{
						blnAchou = true
					}	
				}	
			}
		}
		if (!blnCamposSel)
		{
			alert("Selecione pelo menos um campo da lista de \"Campos Selecionados\"\nque ainda n�o foi selecionado para filtro.")
			return
		}
		if (blnAchou)
		{
			alert("Alguns campos j� est�o selecionados como filtros!")
		}
		spnFiltro.innerHTML += strHtml
	}	
}

//Remove um campo que esta como filtro
function RemoverFiltro(strSpan,strChave)
{
	//alert("RemoverFiltro")
	var strSpanAux = new String(strSpan)
	eval(strSpanAux+".innerHTML = \'\'")

	for(var intIndex=0;intIndex<objAryFiltro.length;intIndex++)
	{
		if (objAryFiltro[intIndex] == strChave)
		{
			objAryFiltro[intIndex] = ""
		}
	}
}

//Objeto array onde est�o os filtro ativos/selecionados
var objAryFiltro = new Array()

//Verifica se um filtro j� foi adicionado
function VerificarFluxo(strChave)
{
	//alert("VerificarFluxo")
	for(var intIndex=0;intIndex<objAryFiltro.length;intIndex++)
	{
		if (objAryFiltro[intIndex] == strChave)
		{
			return true
		}
	}
	return false
}

//Adicionar valor do DM para campo escondido para valida��es
function AddValorDM(obj)
{
	//alert("AddValorDM")
	with (document.forms[0])
	{
		hdnDM.value = obj.value

	}	
}

//Limpar filtros,consulta e parametriza��es permanecendo como os campos defeult
function AddValorSOL(obj)
{
	//alert("AddValorSOL")
	with (document.forms[0])
	{
		hdnSolId.value = obj.value

	}	
}

//Limpar filtros,consulta e parametriza��es permanecendo como os campos defeult
function LimparCosultaGeral(objXml,booBtnLimpar)
			{
	//alert("LimparCosultaGeral")
	with (document.forms[0]) {

		if (booBtnLimpar) {
			for (var intIndex = 0; intIndex < objAryFiltro.length; intIndex++) {
				objAryFiltro[intIndex] = ""
			}
		}
			try{ //Pode n�o existir
			//IFrmProcesso.spnConsulta.innerHTML = ""
			IFrmProcesso.Form1.innerHTML = ""
			}catch(e){}	

		if (booBtnLimpar) {
			location.reload();
			CarregarCombo(4)
			spnFiltro.innerHTML = ""
			spnLinks.innerHTML = ""
			hdnCampos.value = ""
			hdnDM.value = ""
			hdnWhere.value = ""
			//document.forms[0].item(8).value = ""
			//document.forms[0].item(9).value = ""
			//document.forms[0].item(10).value = ""
			//document.forms[0].item(11).value = ""
			AdicionarItensDefault(objXml)
	}	
	}
	AddFiltrosDefault()	
}

//Envia para tela que detalha o pedido
function DetalharItem(dblSolId)
{
	//alert("DetalharItem")
	with (document.forms[0])
	{
		hdnSolId.value = dblSolId
		hdnAcao.value = "DetalheSolicitacao"
		target = "DetalheSolic"
		action = "ConsultaGeralDet.asp"
		submit()
	}	
}

//Adiciona itens default para o combo de campos selecionados
function AdicionarItensDefault(objXml)
{
	
	//alert("AdicionarItensDefault")
	var objNode = objXml.selectNodes("//xDados/*")
	with (document.forms[0]){
		for(var intIndex = 0 ; intIndex<objNode.length; intIndex++){
			//Carrega op��es do combo text/value
			if (objNode[intIndex].text != ""){
				if (RequestNode(objXmlGeral,objNode[intIndex].nodeName) == ""){
					var option_combo = new Option(objNode[intIndex].text,objNode[intIndex].nodeName)
					var option_combo1 = new Option(objNode[intIndex].text,objNode[intIndex].nodeName)
					cboCamposSel.options[cboCamposSel.length] = option_combo
					cboOrderBy.options[cboOrderBy.length] = option_combo1
					AdicionarNode(objXmlGeral,objNode[intIndex].nodeName,objNode[intIndex].nodeName)
				}	
			}	
		}
	}	
}

function AddFiltrosDefault()
{
	//alert("AddFiltrosDefault")
	var strHtml = new String("")
	var blnAchou = false
	var blnCamposSel = false
	var objAtyTipo
	var strTipo
	var strValida
	var strMaxLen
	var strValidaIII
	//alert(objAryFiltroDef.length)
	//alert('1')
	with (document.forms[0])
	{
		for(var intIndex=0;intIndex<objAryFiltroDef.length;intIndex++)
		{
			if (objAryFiltroDef[intIndex].toUpperCase() == "Cla_Pedido.NumerodoPedido-A-".toUpperCase())
			{
				if (!VerificarFluxo(objAryFiltroDef[intIndex].toUpperCase()))
				{
					var strNomeSpan =  "spn"+Math.round(Math.random()*100000)
					strHtml += "<span id='"+strNomeSpan+"'>"
					strHtml += "<table border=0 width=100% cellspacing=1 cellpadding=0><tr class=clsSilver><td width=200px >"+objAryFiltroDefNome[intIndex]+"</td><td><input type=text size=20 class=text name='"+objAryFiltroDef[intIndex].toUpperCase()+"' value='DM-'  onBlur='AddValorDM(this)' >"
					strHtml += "<input type=button class=button onmouseover=\"showtip(this,event,\'Remover Filtro\') \" style=\'width:15px;BORDER-LEFT-STYLE: none\' name='btnRem"+intIndex+"' value='X' onclick=\"RemoverFiltro('"+strNomeSpan+"','"+objAryFiltroDef[intIndex].toUpperCase()+"')\" >"
					strHtml += "&nbsp;DM-NNNNN/ANO</td></tr></table></span>"
					objAryFiltro[parseInt(objAryFiltro.length+1)] = objAryFiltroDef[intIndex].toUpperCase()
					blnCamposSel = true
				}
				else
				{
					blnAchou = true
				}	
			}
			else
			{
				if (!VerificarFluxo(objAryFiltroDef[intIndex].toUpperCase()))
				{
					
					objAtyTipo = objAryFiltroDef[intIndex].split('-')
					strValida = ""
					strTipo = ""
					strMaxLen = ""
					strValidaII = ""
					strValidaIII = ""
					switch (objAtyTipo[1])
					{
						case "D":
							strTipo = "(dd/mm/aaaa)"
							strValida = 'OnlyNumbers();AdicionaBarraData(this)'
							strValidaII = 'if (!ValidarTipoInfo(this,1,"'+objAryFiltroDefNome[intIndex]+'")){this.focus()}'
							strMaxLen = " maxlength=10 "
							break
						case "N":	
							strValidaIII = 'ValidarTipo(this,0);'
							break
					}

					if (objAryFiltroDef[intIndex].toUpperCase() == "CLA_Solicitacao.Sol_Id-N-".toUpperCase())
					{
					var strNomeSpan =  "spn"+Math.round(Math.random()*100000)
					strHtml += "<span id='"+strNomeSpan+"'>"
						strHtml += "<table border=0 width=100% cellspacing=1 cellpadding=0><tr class=clsSilver><td width=200px >"+objAryFiltroDefNome[intIndex]+"</td><td>"
						strHtml += "<input type=text class=text size=20 "+strMaxLen+" name='"+objAryFiltroDef[intIndex].toUpperCase()+"' onKeyPress=\'"+strValida+"\' onBlur='AddValorSOL(this)' onKeyUp=\'"+strValidaIII+"\' >"
						strHtml += "<input type=button class=button onmouseover=\"showtip(this,event,\'Remover Filtro\') \" style=\'width:15px;BORDER-LEFT-STYLE: none\' name='btnRem"+intIndex+"' value='X' onclick=\"RemoverFiltro('"+strNomeSpan+"','"+objAryFiltroDef[intIndex].toUpperCase()+"')\" >"
						strHtml += "&nbsp;"+strTipo+"</td></tr></table>"
						strHtml += "</span>"
						objAryFiltro[parseInt(objAryFiltro.length)] = objAryFiltroDef[intIndex].toUpperCase()
						blnCamposSel = true
					}
					//Else if (objAryFiltroDef[intIndex].toUpperCase() == "CLA_Solicitacao.Sol_Id-N-".toUpperCase())
					//{
					//	var strNomeSpan =  "spn"+Math.round(Math.random()*100000)
					//	strHtml += "<span id='"+strNomeSpan+"'>"
					//	strHtml += "<table border=0 width=100% cellspacing=1 cellpadding=0><tr class=clsSilver><td width=200px >"+cboCamposSel[intIndex].text+"</td><td>"
					//	strHtml += "<input type=text class=text size=20 "+strMaxLen+" name='"+objAryFiltroDef[intIndex].toUpperCase()+"' onKeyPress=\'"+strValida+"\' onBlur='AddValorSOL(this)' onKeyUp=\'"+strValidaIII+"\' >"
					//	strHtml += "<input type=button class=button onmouseover=\"showtip(this,event,\'Remover Filtro\') \" style=\'width:15px;BORDER-LEFT-STYLE: none\' name='btnRem"+intIndex+"' value='X' onclick=\"RemoverFiltro('"+strNomeSpan+"','"+objAryFiltroDef[intIndex].toUpperCase()+"')\" >"
					//	strHtml += "&nbsp;"+strTipo+"</td></tr></table>"
					//	strHtml += "</span>"
					//	objAryFiltro[parseInt(objAryFiltro.length)] = objAryFiltroDef[intIndex].toUpperCase()
					//	blnCamposSel = true
						
					//}
					else{
						if (objAryFiltroDef[intIndex].toUpperCase() == "CLA_ORDERENTRY.IA-A".toUpperCase()) {
							//alert(objAryFiltroDef[intIndex].toUpperCase())
							var strNomeSpan = "spn" + Math.round(Math.random() * 100000)
							strHtml += "<span id='" + strNomeSpan + "'>"
							strHtml += "<table border=0 width=100% cellspacing=1 cellpadding=0><tr class=clsSilver><td width=200px >" + objAryFiltroDefNome[intIndex] + "</td><td>"
							
							strHtml += "<input type=text title='XXXXXXXX' maxlength='8' size='8' class=text name='" + objAryFiltroDef[intIndex].toUpperCase() + "-1'								onblur='CompletarCampoIA(this)' TIPO='A' >&nbsp;IA "
							strHtml += "<input type=text title='Numero'   maxlength='4' size='4' class=text name='" + objAryFiltroDef[intIndex].toUpperCase() + "-2' onKeyUp='ValidarTipo(this, 0)' onblur='CompletarCampoIA(this)' TIPO='N'>&nbsp;/ "
							strHtml += "<input type=text title='Ano'      maxlength='4' size='4' class=text name='" + objAryFiltroDef[intIndex].toUpperCase() + "-3' onKeyUp='ValidarTipo(this, 0)' onblur='CompletarCampoIA(this)'>"

							strHtml += "<input type=button class=button onmouseover=\"showtip(this,event,\'Remover Filtro\') \" style=\'width:15px;BORDER-LEFT-STYLE: none\' name='btnRem" + intIndex + "' value='X' onclick=\"RemoverFiltro('" + strNomeSpan + "','" + objAryFiltroDef[intIndex].toUpperCase() + "')\" >"
							strHtml += "&nbsp;XXXXXXXIANNNNANO</td></tr></table></span>"
							objAryFiltro[parseInt(objAryFiltro.length + 1)] = objAryFiltroDef[intIndex].toUpperCase()
							blnCamposSel = true

						}
						else{
							//alert("Entrou")
							var strNomeSpan = "spn" + Math.round(Math.random() * 100000)
							strHtml += "<span id='" + strNomeSpan + "'>"
							strHtml += "<table border=0 width=100% cellspacing=1 cellpadding=0><tr class=clsSilver><td width=200px >" + objAryFiltroDefNome[intIndex] + "</td><td>"
					strHtml += "<input type=text class=text size=20 "+strMaxLen+" name='"+objAryFiltroDef[intIndex].toUpperCase()+"' onKeyPress=\'"+strValida+"\' onBlur=\'"+strValidaII+"\' onKeyUp=\'"+strValidaIII+"\' >"
					strHtml += "<input type=button class=button onmouseover=\"showtip(this,event,\'Remover Filtro\') \" style=\'width:15px;BORDER-LEFT-STYLE: none\' name='btnRem"+intIndex+"' value='X' onclick=\"RemoverFiltro('"+strNomeSpan+"','"+objAryFiltroDef[intIndex].toUpperCase()+"')\" >"
					strHtml += "&nbsp;"+strTipo+"</td></tr></table>"
					strHtml += "</span>"
					objAryFiltro[parseInt(objAryFiltro.length)] = objAryFiltroDef[intIndex].toUpperCase()
					blnCamposSel = true
				}
					}
					
				}
				else
				{
					blnAchou = true
				}	
			}	
		}	
	}	
	spnFiltro.innerHTML += strHtml
}


function ValidaSelecao(campo){

	//alert("ValidaSelecao")
	with (document.forms[0])
		{
			try{
			for (var i = 0 ; i < cboCamposSel.length; i++  ){
				if (campo == cboCamposSel[i].value)	return false
			}
			return true 
			}
			catch(e){
				alert(e.description)
			}
		}
}

function CompletarCampoIA(obj) {
	//alert("CompletarCampoIA")
	//alert(obj.value)
	if (obj.value != "" && obj.value != 0) {
		var intLen = parseInt(obj.size) - parseInt(obj.value.length)

		switch (obj.TIPO.toUpperCase()) {
			case "N":
				for (var intIndex = 0; intIndex < intLen; intIndex++) {
					obj.value = "0" + obj.value
				}
				break
			default:
				//for (var intIndex = 0; intIndex < intLen; intIndex++) {
					//obj.value = obj.value + " "
					//alert(obj.value)
				//}
		}
	}
}

function htmlEncode(str) {
	var div = document.createElement('div');
	div.appendChild(document.createTextNode(str));
	return div.innerHTML;
}

function validarEncode(inputElem) {
	original = inputElem.value;
	codificado = htmlEncode(original);
	if (original.length !== codificado.length) {
		alert("Valor inv�lido no campo!")
		inputElem.value = ""
		return false
	} else {
		codificado = LimparTextoSql(original);
		if (original.length !== codificado.length) {
			alert("Valor inv�lido no campo!")
			inputElem.value = ""
			return false
		} else {
			inputElem.value = codificado
		}
	}
	return true
}

function LimparTextoSql(str) {
	str = str.replace(/^\s+|\s+$/g, ""); // Trim
	str = str.toLowerCase(); // Convert to lowercase
	str = str.replace(/=/g, "");
	str = str.replace(/'/g, "");
	str = str.replace(/""/g, "");
	str = str.replace(/ or /g, "");
	str = str.replace(/ and /g, "");
	str = str.replace(/\(/g, "");
	str = str.replace(/\)/g, "");
	str = str.replace(/</g, "");
	str = str.replace(/>/g, "");
	str = str.replace(/update/g, "");
	str = str.replace(/-shutdown/g, "");
	str = str.replace(/--/g, "");
	str = str.replace(/#/g, "");
	str = str.replace(/\$/g, "");
	str = str.replace(/%/g, "");
	str = str.replace(/�/g, "");
	str = str.replace(/&/g, "");
	str = str.replace(/'or'1'='1'/g, "");
	str = str.replace(/insert/g, "");
	str = str.replace(/drop/g, "");
	str = str.replace(/delete/g, "");
	str = str.replace(/xp_/g, "");
	str = str.replace(/select/g, "");
	str = str.replace(/\*/g, "");
	str = str.replace(/http/g, "");
	str = str.replace(/:/g, "");
	//str = str.replace(/\//g, "");
	str = str.toUpperCase(); // Convert to UpperCase
	return str;
}